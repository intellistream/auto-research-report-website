---
title: "面向大语言模型服务的推测解码综述"
subtitle: "Speculative Decoding for Large Language Model Serving: A Survey"
lang: zh-CN
---

## 摘要 {.unnumbered #abstract-zh}

推测解码利用低成本候选与目标并行验证减少自回归生成的串行调用，但接受长度提高并不必然降低在线服务的单位输出成本。本文系统梳理截至 2026 年 11 月 18 日的代表性机制与服务实现，围绕候选如何成为符合目标输出语义、具有合法执行状态且能够持续生成的有效输出建立分析框架。首先区分模型因果关系、候选拓扑与设备执行形状，阐述贪心一致、精确采样、状态提交和单位有效输出时间的共同约束；其次比较草稿来源与依赖结构、目标验证预算、Transformer KV 与循环状态的接受路径恢复，以及动态服务中的资源共享和异步重叠；最后综合配对实验与主流推理框架的执行路径，分析候选质量、真实目标工作、状态可见性和 SLO 表现之间的关系。现有证据表明，增加候选或提高接受率未必减少实际执行时间，局部状态与算子优化也可能因缓存容量、等待和请求排队而失去服务收益。本文据此提出可通过强基线检验的状态生命周期、路由感知预算、服务效用训练与跨负载迁移问题。

**关键词：** 推测解码；目标验证；精确采样；合法前缀状态；大语言模型服务

## Abstract {.unnumbered #abstract-en}

Speculative decoding reduces serial target-model invocations by combining inexpensive proposals with parallel verification. Yet a longer accepted prefix does not necessarily lower the cost per output token in an online serving system. This survey reviews representative studies and version-pinned implementations available through November 18, 2026, focusing on how speculative candidates become target-consistent outputs backed by valid execution state. We distinguish model causality, proposal topology, and device execution shape, and use a common framework to examine greedy equivalence, exact sampling, committed-prefix state, and effective output cost. We then compare proposal sources and dependencies, verification budgets, accepted-path state recovery for Transformer and recurrent layers, and resource sharing and asynchronous overlap in serving runtimes. Evidence from matched author-reported experiments and fixed implementation paths reveals three interacting boundaries: proposal quality must yield useful target progress, committed outputs must have consumable state, and local computational savings must survive actual device execution and shared-resource constraints. We formulate testable questions for state lifecycle management, routing-aware budgeting, serving-oriented draft training, and transfer across workloads and platforms. The resulting synthesis identifies the semantic and execution conditions under which speculative decoding can provide sustained serving benefits.

**Keywords:** speculative decoding; target verification; exact sampling; committed-prefix state; LLM serving

# 引言 {#introduction}

自回归语言模型能够对已知序列的多个位置并行评分，却必须在生成时先确定当前位置的 token，才能形成下一位置的合法前缀。对每轮只推进少量输出的请求，目标模型仍需访问权重、读取历史状态并提交设备任务。推测解码利用已给定候选可以被目标一次前向评分的性质，以较便宜的提议计算减少昂贵的串行目标调用。它没有取消输出的因果关系，而是通过目标授权的接受、拒绝及纠正规则，使一次验证可能提交多个合法位置。[@blockwise; @leviathan; @chen]

然而，增加单轮潜在输出与降低在线服务成本是两个不同目标。较长的候选可能提高路径覆盖，也会增加草稿计算和被拒后缀的无效工作；较宽的验证可以摊销部分权重访问，却可能改变 Attention、MoE 专家、缓存和通信负载。更关键的是，被验证器接受的 token 必须对应可供后续消费者读取的合法目标状态。因此，候选接受长度、实际目标查询行、状态提交开销和请求完成时间虽然关联，却不能相互替代。[@illusion; @magicdec; @smartspec; @hybridspec]

已有研究从不同环节改善这些约束。Blockwise Parallel Decoding 与经典推测采样建立多位置提议、前缀确认及目标分布保持的基础；SpecInfer 将候选组织为共享前缀的树，Medusa 和 EAGLE 家族分别通过目标特征读出和未来表征预测提高覆盖。DFlash 以块并行减少草稿 backbone 的串行步，DSpark 在并行 backbone 后补充低成本因果条件；树构造和动态预算进一步决定哪些候选被实际验证。它们改变的分别是提议信息、候选依赖、逻辑几何或目标执行预算，而不只是同一个“候选数”指标。[@blockwise; @leviathan; @chen; @specinfer; @medusa; @eagle; @eagle3; @dflash; @dspark]

动态 Serving 与混合模型使状态问题成为必不可少的一环。多个请求共享执行批次，MoE 目标的专家路由使新增查询行价格不均匀，GDN 等循环层又要求拒绝后持久状态与接受路径一致。HybridSpec、Twig 和 ReplaySSM 分别展示阶段化验证、路径状态重建及检查点表示的取舍；固定运行时中接受计数、设备缓存和主机元数据的可见性也可能处于不同边界。逻辑验证成功、状态可供消费和真实关键路径缩短，需要分别建立证据。[@forespark; @hybridspec; @twig; @replayssm; @ascend-pin]

相关研究已经建立了从候选质量到系统效率的多层分析路径。Ji 等以候选生成、目标验证及系统执行的约束讨论推测优化，Zhao 等进一步从 Draft Source、Draft Geometry、Verification Fidelity 和 Runtime Execution 分析方法之间的结构联系。两种视角共同表明，算法局部最优不必对应服务端到端最优。围绕这一问题，本文将研究对象进一步落实为可观察的执行过程：候选如何经过目标验证成为合法输出，相关前缀状态如何支持下一轮计算，增加的候选工作又如何改变真实设备成本。[@ji2026survey; @zhao2026survey]

全文沿三项互相关联的机制组织。其一，区分模型因果关系、候选拓扑与设备执行形状，以判断不同草稿与验证方法改变了哪些依赖及计算。其二，联合考察输出分布、KV/循环状态的接受路径提交以及元数据的跨轮可见性，建立从输出语义到可消费执行状态的对应。其三，将目标查询行、草稿与状态成本、执行关键路径及在线 SLO 置于共同的测量边界，解释收益随模型、后端和负载变化的原因。

第二节交代文献范围与评价口径；第三节建立正确性、状态与成本模型。第四、五节分别讨论候选生成和目标验证，第六节考察合法状态及运行时接口，第七节分析动态服务与资源耦合。第八节在配对实验和跨工作比较中归纳证据，第九节讨论尚待解决的联合设计问题，最后概括全文的系统性结论。

# 研究范围与文献获取 {#scope}

本文采用机制驱动的技术综述方法，在共同的生成语义与服务执行边界下比较算法研究、系统实现与实证评估。算法证明用于确定输出分布和接受路径的成立条件，运行时实现用于揭示状态生产、发布与消费的执行关系，而配对消融和在线测评用于归因实际性能变化。研究问题由这些证据的相互约束形成。[@ji2026survey; @zhao2026survey; @leviathan]

## 工作边界与纳入依据 {#selection}

本文采用问题导向的叙述性技术综述，研究对象是自回归目标模型上经过提议、验证与状态提交的推测执行。纳入的研究至少须解释候选如何生成或组织、目标如何判定接受与纠正、已提交状态如何恢复，或上述步骤怎样影响 Serving 性能。训练方法仅在影响候选分布或接受路径时进入主论证；长上下文、约束生成、混合循环架构及多模态负载，用于说明特定计算与状态约束。与推测执行无直接关系的通用优化不作为核心方法比较。

资料截点为 2026 年 11 月 18 日。以既有 Decoding Acceleration 索引及专题检索记录为入口，按系统名、论文题名、DOI、arXiv 编号与组合关键词追查完整方法、实验、官方文档和固定源码，再合并同一成果的首发、修订及正式版身份。检索以机制间的可比性、完整实验条件及具有解释力的反例为主要纳入依据。[@awesome-index; @website-index]

每项方法首先区分候选的实际生成来源，再记录候选在验证器接口上的逻辑几何和相应输出保证。这里的 Chain、Block、Tree 与 Collection 并非按设备是否并行发射划分；候选来源、几何及 fidelity 也不能相互代替。同一方法可能继承多个接口，但其核心贡献仍以原文说明为准。上述分类为后文的跨层机制比较提供一致的术语，并将候选、验证、状态与成本置于不同的决策维度。[@zhao2026survey; @specinfer; @spectr; @medusa; @dflash]

## 研究证据与版本对应 {#source-versions}

推测解码文献中的理论保证、算法组件收益和服务测评对应不同的观察范围。经典拒绝采样与 Block Verification 的推导约束候选条件分布和验证规则；树形方法的机制实验展示路径覆盖与验证行数的关系；在线 Serving 研究则在指定模型、硬件、请求流与 SLO 下测量吞吐、时延和资源竞争。这些研究构成由算法语义到系统执行的分层证据：数学保证规定可执行的状态转换，局部消融识别组件作用，配对服务测量检验总效用。[@leviathan; @spectr; @blockverification; @illusion; @forespark]

同一成果的发表稿、预印本与补充材料按统一研究身份整理，具体机制与实验以实际采用的版本为准。例如 AdaServe 的服务评估、EVICT 的树预算策略、ForeSpark 的前后两阶段预算以及 Twig 的循环状态恢复分别对应不同的论文版本和实现条件。HybridSpec 对 ReplaySSM 的比较发生在相应 SGLang 评测环境中，与 ReplaySSM 的算法和工程设计形成互补说明。比较表中的 Target、Drafter、精度、采样方式、并行配置与工作负载共同确定实验的归因范围。[@adaserve; @evict; @forespark; @twig; @hybridspec; @replayssm]

官方文档和固定版本的 vLLM、vLLM-Ascend 与 SGLang 源码进一步揭示候选行的准备、目标采样、接受计数回传和状态提交等软件路径；代码变更中的局部测量用于解释接口及执行顺序的成本。本文在第六节以这些执行机制对应前述语义与成本模型，并在第八节结合性能实验讨论哪些局部调整影响实际关键路径。[@vllmdocs; @ascenddocs; @vllm-pin; @ascend-pin; @sglang-pin; @pr-recover; @pr-d2h]

# 正确性、前缀状态与单轮成本 {#framework}

推测轮次首先是保持目标输出语义的状态转换，其次才是降低执行成本的策略。模型因果关系、验证器可见的候选拓扑、设备实际执行的查询行和最终提交的输出不是同一种对象。本节先定义这些观察单位，再建立贯穿后续方法比较的保真度、合法状态和单位输出成本条件。[@leviathan; @specinfer]

## 一轮执行的观察边界 {#round}

将一轮开始时已对外提交的 token 前缀记为 $h$。草稿提出长度 $D$ 的候选链 $y_{1:D}$，或给出具备父指针的候选树。验证器对链中 $K$ 个候选或树中 $N$ 个候选节点求值。树中同层节点可能是互斥后继，实际输出只能沿一条从已提交前缀开始的合法路径。令 $A$ 表示该轮接受的草稿 token 数，$R$ 表示实际新增并提交的输出 token 数。全数接受时的 bonus token 或首次拒绝后的目标纠正 token 可能使 $R=A+1$。遇到 EOS、长度上限或取消时，按实际提交计数。实现也可能将本轮的最后一个新 token 留到下轮前向作为 anchor；应注明计算行是否含 anchor，避免将验证行数、草稿数和提交数混用。[@leviathan; @chen]

Table: 表 1　单轮与批次的比较记号。时间以墙钟或明示的设备计时口径记录，长度以对应对象计数。

| 记号 | 对象 | 含义 |
|:--|:--|:--|
| $h,c,S_c$ | 提交与物化状态 | 逻辑前缀、已物化边界、该边界的执行状态 |
| $D,K,N$ | 候选与预算 | 草稿链长、验证链长、树验证节点数 |
| $A,R$ | 进度 | 接受的草稿数、实际提交的输出数 |
| $B,L,Q$ | 执行形状 | 活跃解码请求数、上下文长度向量、实际目标查询行数 |
| $T_0,T_{\mathrm{spec}}$ | 关键路径 | 同配置普通解码步与推测轮的时间 |

图 1 给出从候选生成到合法状态物化的一轮执行职责；各阶段的真实成本还取决于设备形状、调度等待及跨轮状态发布。

![图 1　推测轮次、前缀状态与成本的关系。框中 $D$、$K$、$N$ 与 $R$ 的定义见表 1。箭头表示依赖与职责。](figures/specdec-round.png){#fig-round width=100%}

## 因果图、候选图与执行形状 {#three-objects}

分析推测解码时首先要区分三类对象。模型因果关系确定每个位置允许依赖的语义历史。候选图记录本轮打算搜索的路径，每个节点的身份由父节点、位置和 token 共同决定。执行形状则由运行时选择的请求行、padding、块表和 kernel 组成。候选图到执行形状的映射可以将若干分支组织成同一验证批次，也可能因后端约束拆成多个调用。共享前缀下两个相同 token 如果来自不同父路径，通常具有不同的隐藏状态和后继分布。只有实际历史相同的候选，才能在支持该合并的执行路径中共用一次目标求值。[@specinfer; @sequoia; @flashinfer]

候选拓扑和执行顺序也影响成本归因。以根后只考虑 $a$、$b$ 两个分支为例，如果目标先在根输出 $b$，$a$ 分支所有后继都失去成为本轮输出的可能性。早期提案正确带来的价值取决于其后还有多少可继续的节点。若模型先验证整个树，$a$ 子树仍占用发射与内存资源。若采用分阶段验证，可以省掉部分昂贵目标操作，但必须额外处理裁剪、目标因果视图和两阶段串联。第[五节](#verification)区分了目标一次性给所有节点打分、在预算下选择子树以及按阶段决定是否继续三种执行安排。[@specinfer; @evict; @hybridspec]

同一关系还解释预填充和验证的相似与边界。两者都可以让多条 query 读取一段既有历史，验证还要处理同一轮候选间的祖先约束，且只发布被接受的状态。运行时可以复用支持变长、多 query 的 attention 组织能力，但仍需给候选行绑定正确的请求、位置与掩码。因而，候选节点总数和预填充 token 总数相同，只提供了局部 shape 信息。[@flashinfer; @specinfer; @pagedattention]

图 2 将候选行、共享形状约束与设备执行工作分开表示。草稿、目标验证、接受扫描及状态发布可以具有不同的逻辑行数；运行时依据批次、上下文与验证宽度映射为实际前向、扫描和状态操作。图中方块数量仅为结构示意，不对应实测 token 数量或 kernel 时长；真实成本按有依赖关系的执行、等待和发布路径计量。

![图 2　推测轮次中的候选行与设备执行形状映射。逻辑行数、设备工作量与状态发布边界分别表示，方块仅为示意。](figures/execution-shape.png){#fig-execution width=100%}

## 验证规则决定保真度 {#fidelity}

在给定相同 tokenizer、前缀、logits 变换和 tie-breaking 的数学模型下，贪心验证逐位置比较候选与目标 argmax，在第一个不匹配处由目标决定输出，沿因果路径归纳可得贪心一致。有限精度下，宽验证与逐 token 运行可能选择不同 kernel 或归约顺序。若目标的两个最高 logit 接近，微小差异也能改变 argmax。应分别说明数学保证与实测 token 一致率。放宽到 top-$k$ 或以分数阈值直接接受，则改变了承诺，评估应回到任务质量或明确的近似准则。[@blockwise; @chen]

精确的 token-wise 推测采样在每个已经沿草稿到达的位置使用两份条件分布。$p_i(v)$ 是目标实际抽样分布，$q_i(v)$ 是生成当前草稿 token 的真实分布，条件均为该位置的合法前缀，包含各自生效的温度、截断及其他变换。对 $y_i\sim q_i$，接受概率与首次拒绝的纠正分布分别为
$$
a_i(y_i)=\min\{1,p_i(y_i)/q_i(y_i)\},\qquad
r_i(v)=\frac{[p_i(v)-q_i(v)]_+}{\sum_u[p_i(u)-q_i(u)]_+}.
$$

接受的概率质量为 $\min(p_i(v),q_i(v))$，总拒绝质量为 $\sum_u[p_i(u)-q_i(u)]_+$，补回后恰得 $p_i(v)$。当分母为零时，该拒绝分支以概率零发生。所有候选被接受后，额外输出从下一位置的目标分布采样。跨位置的保证依赖条件分布与已提交前缀一致，因而同一随机种子下出现不同序列与分布正确性可以同时成立。树、多候选以及 block verification 各需核对自身的选择与纠正规则。[@leviathan; @chen]

预算裁剪也有保真度前提。若在抽得本位置候选前按已知前缀和分数决定是否验证，经典规则可继续使用对应的条件 $q_i$。若选择依赖已经抽出的候选，验证器须匹配被选择对象的条件分布，或采用有独立证明的联合机制。以数学反例说明：令 $p=q$ 为二元均匀分布，只在候选为 1 时用原 $q$ 验证，否则从 $p$ 重新采样。被验证的 1 总被接受，最终输出 1 的概率成为 $3/4$。这里产生偏差的原因是送去验证的候选已经改变分布。贪心前缀裁剪还有自己的一组条件，主要是目标计算的因果不变性、fallback 及状态重建。[@leviathan]

随机验证的可复用结论来自单步概率质量，而非草稿 token 与目标独立随机样本的逐次相等。对单个提议，条件接受概率的期望为
$$
\sum_v \min\{p_i(v),q_i(v)\}
=1-\tfrac12\sum_v |p_i(v)-q_i(v)|.
$$
这里的分布都以同一合法历史为条件，结果表明改进草稿和调温度都会改变重叠。对固定但确定性的草稿 token $d$，可取 $q_i=\delta_d$。此时接受概率为 $p_i(d)$，剩余质量恰由目标分布排除 $d$ 后补足。该性质允许从检索、贪心草稿等机制提交一个候选，同时保持目标随机采样；接受率的解释需要对应点质量，而不能用预测该 token 的 softmax 分数充当 $q_i(d)$。[@leviathan; @chen; @hybridspec]

对树也可以构造一种直接的精确基准：到达已知前缀时先按该前缀的目标分布独立抽一个 token，只在树上有对应子节点时继续利用已预先计算的状态。对于单层剪枝，候选只决定本轮是否还能沿树继续，发布的 token 始终来自目标抽样。若进一步希望借多候选联合分布增加接受机会，则要处理候选相关性、重采样以及连续条件分布。SpecTr 的集合成员代价和 SpecInfer 的随机树验证分别回答了单位置多提议及多分支验证里的部分问题，适用的候选前提各有区别。这里也解释了为什么树验证的正确性需要同时核对模型掩码和采样过程。[@specinfer; @spectr; @sequoia]

## 合法前缀状态与发布 {#state-invariant}

用 $c\le |h|$ 表示目标实际物化到的位置，$S_c$ 包括目标侧有效 KV、循环层及卷积状态，以及后续读取所需的索引和长度。对给定目标配置 $\theta$，状态契约要求
$$
S_c \simeq F_{\theta}(h_{1:c}),\qquad
\mathrm{pending}=h_{c+1:|h|}.
$$
$F_{\theta}$ 表示普通解码对该前缀的状态计算，$\simeq$ 表示对后续目标计算可观察等价，有限精度时应给出容差或差分指标。物理块地址可以不同，逻辑位置、请求归属、有效范围和读写依赖必须相符。未提交分支可以暂存在设备缓冲中，但后续计算、其他请求及前缀缓存不可把它们当成合法历史。草稿缓存属于另一套状态，以其自身模型和同一合法历史重新裁剪、补齐或重建；它不需要与目标 KV 数值相等。[@specinfer; @hybridspec]

这一条件把验证与提交分开。验证器决定哪一段可以输出，提交器据此确定物化边界，必要时回收临时 KV、重建循环状态并发布计数。请求退出、槽位复用、异步 D2H 及图重放会引入额外的消费者排序要求。只检查当前轮返回的 token 可能放过被拒后缀残留到下一轮的问题。有限精度与状态污染也应分别定位，前者通常表现为相同逻辑前缀下的小幅计算差异，后者能通过先核对边界、索引和依赖再做差分来识别。[@specinfer; @hybridspec]

该状态条件可以具体化为三个面向观察者的约束。计算约束要求某一位置的合法 KV、循环状态、卷积状态和位置编码相互对应。可见性约束要求本轮验证用的暂态与对外可复用的前缀分离，并使 token、有效长度与块表在一致的发布边界上推进。寿命约束要求在消费者读完之前保护块、临时缓冲和条件上下文，取消或复用时不得将旧请求的结果发布至新请求。前两项即使在单请求 eager 路径也需要，第三项在异步调度和连续批处理中更容易暴露。SpecInfer 的分支 KV 复用、PagedAttention 的逻辑块映射及第[六节](#runtime)的事件链分别展示了这些约束如何落实。[@specinfer; @pagedattention; @ascend-pin]

考虑已提交前缀 $h$ 后草稿给出 $u,v,w$，其中 $u$ 被接受，$v$ 被拒绝并由目标输出 $z$。本轮对外提交 $u,z$，但通常已经为 $u,v,w$ 写过目标暂态。若 $z$ 尚未作为输入执行，物化边界只推进到 $u$，下一轮用 $z$ 作 anchor。保留 $u$ 后缓存的顺序、长度和索引必须同时截断，含 $v,w$ 的缓存区域不能成为前缀命中。若是循环层，还要恢复到输入 $u$ 后的状态。若请求随 $z$ 结束，可以走清理路径；同一批次其他请求的接受数和读位置各自独立。这个例子区分已输出 token、已前向位置和仍占据物理空间的条目。[@leviathan; @pagedattention; @hybridspec; @vllm-pin]

## 从接受长度到单位有效输出时间 {#cost}

对一条固定长度链，在忽略停止条件时，按 $A$ 的尾和恒等式有 $\mathbb{E}[A]=\sum_{j=1}^{K}\Pr(A\ge j)$。其中每一项是前 $j$ 个位置共同接受的概率，可以写成沿存活路径的条件概率连乘。常见比例模型以所有位置的条件接受概率相同为近似。请求类型、生成位置和已接受历史改变这些条件时，单个全局接受率无法准确恢复 $\mathbb{E}[A]$。同一平均接受率还可以对应不同的拒绝位置与落到关键路径上的恢复成本。[@leviathan; @chen]

设一次执行依赖图中草稿、验证、选择、状态提交和运行时操作的持续时间分别由对应节点记录。串行时这些时间可以相加。存在并行准备、D2H 重叠或跨请求资源竞争时，用已测相互干扰条件下的关键路径时间 $T_{\mathrm{spec}}$，并把排队与调度间隙按测量范围单列。对串行、可比且可作长期统计的解码轮，单位输出代价及收益为
$$
g_{\mathrm{spec}}=\frac{\mathbb{E}[T_{\mathrm{spec}}]}{\mathbb{E}[R]},\qquad
g_0=\frac{\mathbb{E}[T_0]}{\mathbb{E}[R_0]},\qquad
\text{speedup}=\frac{g_0}{g_{\mathrm{spec}}} .
$$
这里用总时间除以总输出的相应估计量。计算批次吞吐时，应以所有请求的实际提交量之和作分子，共同的墙钟窗口只计一次。在线服务还应分别记录请求排队、首 token、token 间隔、完成分位数及 SLO 下的可持续请求率。离线单轮比值用于解释热路径，不能单独推导带到达过程的服务收益。[@illusion; @smartspec]

## 通过率、空闲容量与收益条件 {#break-even}

若各位置在前序皆被接受的条件下通过概率同为 $\alpha$，且不考虑终止截断，链式推测的平均输出进度为
$$
\mathbb{E}[R]=1+\alpha+\cdots+\alpha^K
=\frac{1-\alpha^{K+1}}{1-\alpha},\qquad 0\leq\alpha<1.
$$
当 $\alpha=1$ 时进度为 $K+1$。在这个受限模型中，第 $K$ 个候选的期望贡献为 $\alpha^K$；因此即使浅层接受率很高，深层收益也会随前缀存活概率衰减。训练可以提高某些位置的命中，部署也可以减少原本为深层支付的费用。在非同质场景，应估计分位置存活或直接使用接受长度直方图，而且应注明分母是否包含因早期拒绝而未被访问的位置。[@leviathan; @dspark; @realloss]

对同请求、同目标配置且普通解码每轮输出一个 token 的对照，只有 $\mathbb E[T_{\mathrm{spec}}]/\mathbb E[T_0]<\mathbb E[R]$ 才能得到单位输出时间优势。这个简单关系给出了排障顺序：先确认每轮实际输出、停止条件和目标执行次数，再区分草稿生成、验证查询行、采样、物化、发布和主机等待。更大的 $R$ 可以被更大的 $T_{\mathrm{spec}}$ 抵消。对有重叠的实现，应测量有效依赖链，不能把不同 stream 或设备上同时发生的 kernel 时间重复计入。对连续批处理，还需计入减少一个请求成本所释放的实际资源能否被其他请求利用。[@leviathan; @illusion; @smartspec; @forespark]

# 候选生成与依赖结构 {#drafting}

比较候选方法时，先识别提议计算由谁负责，再辨认未来位置能使用何种条件信息，以及这些结果如何组成链、块或树。同样的平均接受长度可以对应不同的草稿串行深度和目标查询形状。本节将候选来源、条件依赖与几何组织分开，避免按论文名称或速度排名替代机制分析。[@rest; @medusa; @eagle; @dflash]

## 候选所用的信息与计算 {#draft-sources}

候选来源首先决定由谁支付新增计算，以及每个未来位置能够依赖哪些信息。独立自回归 Drafter 沿自身提议历史逐 token 生成，能够为连续位置定义明确的条件提议分布，却引入额外的权重、KV 和串行步骤。REST 则匹配已有文本延续并将结果组织为 trie，从而避免运行神经草稿，但需要支付检索和候选构造开销，效果随语料覆盖与当前生成内容的重复性变化。二者优化的是不同的成本边界：可训练 Drafter 借条件建模获取候选覆盖，检索式候选则利用已经存在的内容减少提议计算；REST 的离线测量不能直接代表 vLLM 轻量 n-gram 路径的服务收益。[@leviathan; @chen; @rest; @illusion]

目标集成式草稿减少独立模型的驻留需求，但并不共享同一种预测接口。Medusa 在目标特征上附加未来 token 预测头，再将局部假设组合为可验证的树；其 typical acceptance 模式还需要与严格随机接受区分。DeepSeek-V3 的 MTP 使用多深度条件模块预测未来位置，训练用途和推理时是否启用相应模块必须按实际配置说明。EAGLE 则利用 Target 表征与前序 token 建立后继特征条件，EAGLE-2 主要改变按上下文置信分配树预算的方式，EAGLE-3 进一步调整所用特征和训练过程中的预测状态。未来 token 直接读出、未来状态传播和候选树构造分别改变了输出头、草稿依赖及验证对象，不能因为都依赖 Target 表征就归为相同的提议机制。[@medusa; @deepseek; @eagle; @eagle2; @eagle3]

对这些路线，应分别测量候选质量与为此支付的关键路径费用。更高的前缀存活概率可能减少目标串行轮数，但额外预测头、词表投影、特征搬运或状态传播可能延长 Draft；若验证端从链转成树，Target 查询行和暂态管理也随之改变。训练时的接受指标、真实候选构造耗时和线上单位提交 token 时间因此是不同层次的证据。只有固定目标语义、候选预算及服务资源，并同时测得 Draft、Verify 和状态提交，才能把端到端收益归于正确的机制。[@eagle3; @medusa; @realloss; @forespark]

## 浅层执行、稀疏历史与候选复用 {#self-speculation}

自推测把草稿限制为 Target 的较便宜路径，从而减少独立 Drafter 的参数驻留，但必须说明具体节省的是层、历史范围还是其他算子工作。LayerSkip 通过训练中间层早退，使浅层能够形成候选并由完整模型路径验证；Kangaroo 也使用浅层与轻量适配器，同时通过置信停止减少低价值的草稿步骤。二者都依赖浅层预测与完整目标之间的衔接，而对训练方式、可复用激活及中间状态寿命提出不同要求。共享权重不是零成本复用，尤其需要检查同轮是否重复计算已经生成的隐藏状态。[@layerskip; @kangaroo]

在长上下文情形下，另一项选择是缩小草稿查询的历史，而不只是减少网络深度。TriForce 用稀疏历史构造分层提议，并让完整 Target 负责全历史的最终判定；MagicDec 进一步分析长历史与批量下的草稿 KV 访问和目标权重摊销。这些方法在草稿侧降低了与上下文长度相关的内存访问，却增加索引、同步或多级验证的约束。相比之下，LayerSkip 主要改变执行层数。两类方法都通过受限路径生成候选，却分别改变执行层数和历史读取量，不能因为都减少独立草稿工作就推断相同的成本瓶颈或适用长度区间。[@triforce; @magicdec; @layerskip]

另一种降低草稿成本的思路是复用既有文本或历史计算；这与使用 Target 浅层并非同一个分类维度。REST 的候选来自检索材料，Lookahead Decoding 则通过 Jacobi 式迭代生成并缓存可重用片段。二者都无需独立的自回归小模型，却分别依赖语料匹配与候选片段覆盖；其候选生产时机、额外计算和缓存容量不应合并成单一的“免草稿”收益。DistillSpec、REAL Loss 与 EDR 则从训练目标改变提议质量，分别关注分布对齐、沿合法路径的接受和完成轮数；训练改善不自动表示部署端会验证更多有价值位置。将候选来源、条件质量和验证预算分别计量，是比较这组异质方法的前提。[@rest; @lookahead; @distillspec; @realloss; @edr]

## 树的路径覆盖与块的生成并行性 {#draft-geometry}

SpecInfer 将候选整理为前缀树，以祖先掩码和位置映射为每个节点计算正确的条件 logits。多个分支共享候选前缀，目标验证只沿被选路径提交，其他节点的暂态必须作废。其 §4.2–4.4 分别讨论树形目标求值及贪心/随机验证，树注意力只提供路径对应的目标分布，随机质量分配仍需对应的算法。相比相同最大深度的一条链，树可能降低早期误猜造成的整段浪费，同时会增加验证行数、掩码构造、缓存写入和树路径管理。树预算比较因此应同时报告深度、节点数及每个已提交 token 对应的实际目标行。[@specinfer; @eagle2]

DFlash 在目标上下文特征的条件下用轻量块扩散草稿一次预测整个块，消除了完整 draft backbone 的逐位置前向。其论文的块预测与目标验证提供了低草稿延迟的机制线索，精确语义仍须落实到部署采用的采样、纠正与状态更新。DSpark 在并行块 backbone 后增加轻量因果 head，使用前一 token 或循环状态修正草稿 logits，恢复块内条件信息，并加上置信估计来控制验证前缀。Domino 类似地将高成本 backbone 与轻量递归的因果修正分开，并通过分阶段训练协调两者。ChainFlow 将并行候选建模为目标特征条件下的少步潜变量流，加入 token feedback，可生成链或树。比较的因果问题是：每增加一段因果条件，接受前缀增长是否覆盖串行 head、词表投影、重估和额外状态开销。[@dflash; @dspark; @domino; @chainflow]

DDTree 把 DFlash 的位置级候选用固定节点预算编成树，增加分叉覆盖。位置分数沿分叉使用时，母路径已经变化，原来的位置边缘分布不再代表实际分支条件。DForkTree 用目标生成语料中的 n-gram PMI 修正分叉附近的候选排序，在 GPU 上构建树。其 Table 1 的主要对照共享草稿、目标验证器和 32 节点预算，但各方法使用在开发集选择的 proposal block 长度。该比较支持联合构树配置的收益，不能单独识别 PMI 在等块长上的贡献。D3Tree 以训练的节点存活 head 估计边际价值，按负载裁剪、匹配目标 GEMM 的形状预算。其多模态实验把视觉条件、模型结构和预算交织在一起，为负载下的几何选择提供证据，文本在线的收益范围仍需对应测量。[@ddtree; @dforktree; @d3tree]

## 宽度、深度与构造代价 {#tree-construction}

树式草稿的两个基本决策是如何获得后继排序、如何用有限预算展开。Medusa 的多头提供位置级候选。Hydra 让第 $j$ 个预测头额外条件化于给定的中间 token，以提升不同父路径下的预测表达。ReDrafter 从目标隐藏状态出发用循环 drafter 及 beam search 生成路径，并动态折叠共同前缀。前者增加预测头之间的条件依赖，后者显式支付 beam 构造以换取候选路径复用。它们与 DSpark 的共享点是补回中间 token 信息，差别在于验证端实际接收的是多路径树还是并行 backbone 后的链前缀。不同实现承担的词表分数、候选去重与 mask 构造也不同。[@medusa; @hydra; @redrafter; @dspark]

预算固定时，宽树适合早期有多个可用后继的前缀，深树适合高概率路径连续命中。一层内的高分节点也可能有共同的低概率祖先，因此节点优先级应反映到达该前缀所需的所有接受事件。Sequoia 用动态规划在给定预算及接受模型下构造树，并通过硬件相关的验证时间选择规模与深度。EAGLE-2 根据请求上下文维护动态候选排序。SpecExec 则针对参数 offload 环境，在昂贵权重传输之间用大量并行候选提升每次访问的有效输出。后者的宽预算来自其 PCIe/显存情境，和驻留模型下的最优宽度可能相差很大。比较树构造时，应同时记录候选搜索时间、已共享的前缀比例、目标节点数及选择后实际提交的路径长度。[@sequoia; @eagle2; @specexec]

块并行草稿可进一步转化为树，收益取决于分叉后的条件质量。对位置边缘分数，主路径后缀的高分不能直接外推到分支路径。DForkTree 通过 n-gram PMI 补充这一条件，D3Tree 用学习得到的存活分数结合负载裁剪。另一类做法是在生成时直接恢复条件依赖，例如 DSpark 的轻量 head 与 Domino 的递归校正。二者构成可比的选择：一类花代价改进候选条件，另一类花代价仅将有价值节点送给目标。二者能否叠加取决于构造时间、目标行的边际价格和状态暂存，而非分别在不同模型上获得的接受长度。[@dforktree; @d3tree; @dspark; @domino]

Table: 表 2　代表性候选生成方法的设计对象、条件依赖与验证接口。

| 研究及核心作用点 | 提议条件与关键依赖 | 主要候选结构 | 主要附加工作及验证边界 |
|:--|:--|:--|:--|
| 小模型采样 [@leviathan; @chen] | 独立自回归条件分布 | 链 | 逐位置草稿、额外模型 KV；目标按实际 $q_i$ 验证 |
| REST、Lookahead [@rest; @lookahead] | 外部文本匹配；历史目标计算产生的片段 | 链或共享片段 | 检索与片段池；仍需目标处理未命中位置 |
| LayerSkip、Kangaroo [@layerskip; @kangaroo] | Target 浅层与适配器 | 链 | 层间状态复用；全模型目标路径负责最终判定 |
| TriForce、MagicDec [@triforce; @magicdec] | 稀疏或较便宜的历史 KV 读取 | 链 | 草稿历史访问与分级成本；目标保留全历史语义 |
| Medusa、MTP [@medusa; @deepseek] | 目标特征读出与逐深度条件模块 | 多头候选、链或树 | 额外头/模块；验证模式由部署明确指定 |
| EAGLE 系列 [@eagle; @eagle2; @eagle3] | 目标特征与预测状态传播 | 链及候选树 | Feature readout、状态传播、动态构树与验证 |
| DFlash、DSpark、Domino [@dflash; @dspark; @domino] | 并行 backbone，后两者增加轻量因果校正 | 块或其前缀 | 块生成与串行校正的权衡；目标必须检查合法路径 |
| SpecInfer、Hydra、ReDrafter [@specinfer; @hydra; @redrafter] | 多提议来源与分支条件建模 | 共享前缀树 | 去重、祖先掩码及暂态；需路径正确的 Target 求值 |
| DDTree、DForkTree、D3Tree [@ddtree; @dforktree; @d3tree] | 位置候选及分叉存活信息 | 父闭合候选树 | 预算内构树、按形状执行与接受路径选择 |

接受目标本身也应与生成代价对齐。REAL Loss 以真实沿路径的接受长度为训练目标，指出用目标轨迹替代接受轨迹可能引入权重偏差。其 Qwen3.6-35B-A3B 和 Domino 的受控实验衡量接受长度的变化。EDR 进一步处理位置落在哪一轮的问题，以目标 rollouts 估计期望轮数。两者分别改善单轮接受目标与多轮计数目标，最终仍要考虑轮时变化，尤其是后缀长度、树形状或不同验证路径会改变目标工作量时。[@realloss; @edr]

# 目标验证与预算选择 {#verification}

候选结构只规定可供验证的对象，并不决定哪些 token 允许提交，也不决定目标实际执行多少工作。验证需要在既定输出保证下决定窗口、节点集合和继续计算的时间点；性能收益取决于因此省去的昂贵工作能否覆盖选择与状态处理开销。本节将 fidelity、预算时机与执行形状分别讨论。[@leviathan; @spectr; @hybridspec; @tabletune]

## 从固定窗口到边际收益 {#marginal-budget}

固定长度链与固定节点数树都用有限预算增加一次目标验证可能覆盖的后继，但新增候选的进度价值随路径而变化。链的深层 token 只有在前序全部被接受时才能贡献输出，树的分支则通过覆盖其他可能后继改善命中；两种候选结构的 Target 查询行、掩码和提交路径不同。与此同时，候选预算增加还可能越过执行图桶、引入额外的 KV 读取或 MoE 专家、扩大重建状态的临时工作。因而“验证位置增加”不能直接等价为“预期有效输出按比例增加”，也不意味着设备时间均匀增长。[@leviathan; @sequoia; @tabletune; @moebytes]

对于一个局部可比较的执行状态，令 $G=\mathbb{E}[R]$ 为单轮预期有效提交量，$C=\mathbb{E}[T]$ 为相同计时边界下的预期轮时，$\lambda=G/C$。新增候选使这两个量分别变化 $\Delta G,\Delta C$ 时，若两方案时长均为正，单位时间有效输出改善等价于
$$
\Delta G>\lambda\Delta C.
$$
这是两种配置的代数比较，不是任意负载下的最优策略定理。$\Delta G$ 必须来自相应 fidelity 规则和合法路径，$\Delta C$ 则需要覆盖草稿、验证、选择、状态物化和可见等待；跨流重叠时按实际关键路径而非耗时简单求和。Block Verification 在固定链提议和所定义验证器族中给出进度最优性，不能直接升级为包括设备图与多请求队列的服务最优性。[@leviathan; @blockverification; @hybridspec]

这一记账关系解释了为什么不同负载会改变最佳预算。MagicDec 分析长上下文及批量条件下草稿侧稀疏 KV 与目标验证摊销的变化；*Performance or Illusion?* 则在多模型和 Serving 配置中展示收益可能随并发、草稿策略和上下文反转。若删减候选后仍落在相同捕获桶内，逻辑上的 $Q$ 变小不一定缩短 Target 时间；若裁剪改变专家并集或 ragged batch，则可能显著减少实际成本。动态验证的比较因此应围绕策略看到的信息、决策时机及真正跳过的工作，而不能只比较所选窗口长度。[@magicdec; @illusion; @tabletune; @evict; @forespark]

## 提议选择与输出保证的对应 {#verification-contracts}

验证器同时承担三个不可替代的职责：在正确的因果历史上计算目标条件分布，根据指定输出保证作出接受或纠正决定，并将所选路径交给状态提交器。第一步依赖候选节点的父关系、目标位置和注意力掩码；第二步依赖采样或贪心语义；第三步依赖运行时能够重建的有效前缀。改变候选拓扑不必改变输出语义，但调整选取策略、候选概率或状态范围可能使已有证明不再适用。[@leviathan; @specinfer; @spectr; @hybridspec]

针对贪心目标，候选树的作用是预先计算多个合法后继，最终沿目标的逐位置 argmax 路径提交。只要已保留节点在裁剪前后取得相同的目标条件值，且缺失后继可以由普通 AR 回退，删减不可能命中的分支不会改变数学意义上的输出。随机目标则不同：目标 logits 本身并不足以决定精确性，验证器还须知道候选如何被抽取和选择。单提议的接受—残差机制以真实条件 $q_i$ 为基础；多个候选被优选或重排后，未经修正地沿用原提议概率，可能改变最后的生成分布。第[三节](#fidelity)的二元反例表明，这种失效不是有限精度误差，而是选择后的提议分布发生了变化。[@leviathan; @chen]

集合、树和整块验证分别改变了可耦合的随机对象。SpecTr 在单个位置的候选集合上研究概率质量分配，Sequoia 结合树预算与其匹配的抽样规则减少冗余候选，Block Verification 在给定候选链上扩展可接受前缀的联合判定。它们的优化目标分别涉及单位置命中、树路径覆盖及固定链内的预期进度，理论结果不能跨问题直接套用。工程落地还需要检验候选联合分布、每条分支的 logits processor 与语法状态、拒绝纠正和 fallback 是否与相应证明一致；仅保留树掩码，并不等于实现了精确多候选采样。[@spectr; @sequoia; @blockverification; @sglangdocs]

放宽验证规则对应另一类公开合同。早期 Seq2seq SpecDec 的阈值策略和 Medusa 的 typical acceptance 可以在给定任务上形成有用的速度—质量折衷，但其经验质量并非目标分布精确性的替代证明。约束生成还要求候选分支的 grammar state、采样变换和目标条件位置跟随同一条合法历史。比较系统的评估应将数学上贪心一致、精确分布采样、已给出误差界的近似方法，以及仅报告任务质量的宽松接受分层；如果原文没有证明误差界，就不能为它附加 bounded-error 保证。[@xia; @medusa; @vllmdocs; @vllm-sampler]

Table: 表 3　目标验证的语义合同、适用结构与实施约束。实现支持的类别必须依据具体 verifier 代码核查。

| 验证语义 | 已有研究与保证对象 | 实施中不可省略的约束 |
|:--|:--|:--|
| 贪心前缀 [@blockwise; @specinfer] | 对同一目标确定性解码路径一致 | 祖先因果、位置、掩码及数值差分 |
| Token-wise exact sampling [@leviathan; @chen] | 与目标的逐位置条件分布一致 | 真实 $q_i$、接受概率、首次拒绝的残差与 bonus |
| 多候选集合或树 [@spectr; @sequoia] | 取决于具体耦合算法的目标分布保证 | 抽样相关性、候选选择律、校正及回退 |
| Block verification [@blockverification] | 论文定义的固定链提议与联合验证保证 | 块耦合、残差实现、接受路径状态 |
| 宽松/阈值接受 [@xia; @medusa] | 指定质量指标下的经验性质 | 明确目标偏离、任务数据与采样配置 |

## 批次、请求与两阶段预算 {#batch-budget}

自适应预算首先需要明确决策发生在什么时候。在自回归 Drafter 尚未产生后继时终止，可以直接减少后续草稿前向；从一次性生成的并行块中选取前缀，只能在后续 Target 不再计算被删位置时节省验证工作；在 Target 层间观察新信息再裁剪，能够利用本轮实测信号，却已支付部分目标代价。这三个决策时点改变了可用信息、可省费用和控制开销，因而不能用“动态窗口”一个标签概括。DISCO 的草稿循环停止、D-Cut 的验证深度选择、EVICT 的 MoE 验证前子树裁剪分别对应不同的动作与成本边界。[@disco; @dcut; @evict]

批内预算进一步受到实际执行形状约束。TableTune 先剖析给定引擎在不同批次和长度下的 step 成本，形成批级长度表并用在线接受统计调整；DSpark 和 vLLM Adaptive Verification 则依赖请求内部的候选存活信息，按预算决定要保留的合法前缀行。vLLM 文档的估计来源包括置信预测、在线校准的 logits 估计与 suffix 统计，具体模式须以部署版本为准。如果后端以统一 graph bucket 或 padding 执行，被剪掉的少量逻辑行不必释放设备时间；相反，支持 ragged packing 的后端才有机会将预算重新分给其他请求。前置排序、预热与图实例的费用也需按关键路径记录。[@tabletune; @dspark; @avdocs]

并行块还要求把“少生成”和“少验证”分开。若 DFlash 类 Drafter 总先生成完整块，即使验证前删掉半数候选，草稿 backbone 的工作也未减少。ForeSpark 在草稿执行前利用可得的 Target 上下文特征决定生成长度，在生成后再利用更详细的候选信息分配验证行，并借助设备端排序与打包降低控制费用。其作者用同 backbone 的简化变体与端到端吞吐、开放到达 SLO 两类指标评估联合预算；在重载 decode-only 与混合 prefill 的 ShareGPT-E2E 之间，方案排序可以不同。这说明预算收益必须同时记录未生成、已生成但未验证、已验证但未提交的工作，而不能全部归入 acceptance。[@forespark; @dflash]

还有两类更外层的选择。SpecSearch 在可行显存与成本集合中校准硬件、再决定 AR、推测和配套精度/长度，作用于部署配置；Hybrid Spark 按内容重复性切换 n-gram 与 DSpark，作用于草稿来源。这些决策可以与局部验证深度共同存在，却改变不同的成本和缓存契约。一个可信的组合实验应从同一固定模型对和负载出发，分别消融来源选择、草稿执行长度、目标预算与图桶切换，并与最强固定配置比较。只有当实际执行行、图形状或省掉的草稿步骤发生变化时，逻辑预算才可能成为真实设备收益。[@specsearch; @hybridspark; @tabletune; @forespark]

## 混合 GDN–MoE 的阶段化验证 {#hybrid-budget}

MoE 目标使单个候选位置的边际验证费用不再由 token 数唯一决定。同一候选批次可能激活不同专家、产生不同的专家并集与通信；GDN 等循环层又引入基于接受路径的状态恢复。专家字节研究分别考虑按激活 slot 和按专家并集计算参数访问，并在其指定内核与 batch-one 条件下考察路由复用。它表明目标成本需要按真实执行路径校准，但不能把某种专家读模型直接推广为所有 TP/EP 后端的费用函数。[@moebytes; @hybridspec]

已有方法的关键差别是**何时获得路由信息**。EVICT 在进入目标前使用路径价值与剖析得到的 MoE 费用裁剪候选树，从而避免为确定不选择的节点支付目标前向。HybridSpec 把部分决定延后：先针对可能追加的位置完成第一段计算，在第一个 MoE router 附近观察该位置对专家集合的增量，再决定是否继续支付余下专家和后续层的费用。因此，前者依赖预先估计，后者以本轮观察替换部分估计，但额外支付前段计算和同步控制。第一个 router 的信息也不能不经测量代表所有后续 MoE 层及通信链。[@evict; @hybridspec]

这种阶段化决策还受两组独立合同约束。第一，裁剪不能改变仍需验证位置的目标条件分布；若硬件采用容量受限的路由或 batch 耦合算子，要核对删行前后保留前缀的 logits 是否等价。第二，随机采样必须使用与候选选取相适应的提议分布和纠正规则。HybridSpec 给出针对其确定性提议和目标采样的点质量验证分析，并在附录中说明因果、精度和状态条件；不能将其证明直接迁移到依赖随机候选值的任意后验筛选。执行成本、数学分布保持与持久状态恢复分别需要验证。[@hybridspec; @leviathan]

因此，对照 EVICT、HybridSpec、固定窗口及普通 AR 时，既要匹配 Target、Drafter、所选候选集合与状态实现，也要分别记录前段 router 开销、真正跳过的专家工作、ragged 打包、状态恢复和最终有效输出。若专家集合近似稳定、图桶使删行无效，或者前段控制占用关键路径，目标内延迟决策可能退化为更简单的预选择。对多请求批次还需检查是否因统一窗口长度丧失逐请求选择的空间；这些都是该机制的实际适用边界，而不是靠接受长度就能判定的结论。[@evict; @hybridspec; @moebytes; @forespark]

# 合法状态与服务运行时 {#runtime}

目标验证通过后，运行时必须使被接受前缀成为下一轮可以消费的模型状态。Transformer 的 KV 映射、GDN 的递归状态和异步计数发布各有不同寿命与依赖；逻辑 token 提交不必等于物化完成。本节以状态表示和固定源码事件链解释接受、恢复与可见性之间的边界。[@specinfer; @hybridspec; @twig; @ascend-pin]

## Transformer KV 与循环状态的提交粒度 {#commit-state}

验证器给出接受路径之后，运行时还必须选择该路径对应的持久模型状态。在因果 Transformer 中，正确历史与位置确定相应的 KV；拒绝后可以保留已接受行、更新有效长度与块表映射，并使其他分支暂态不再可见。树形验证需要区分路径选取与物理页管理：一页中可能同时包含有效和无效位置，页仍被引用不代表其中全部行都属于合法前缀。SpecInfer 的树验证和 PagedAttention 的逻辑映射体现了这种职责差异。Callo 进一步表明旧上下文 KV 可以在特定场景用于提出候选，但最终目标仍需基于新上下文的合法 KV 验证；相关传输等待与推测算法收益应分别归因。[@specinfer; @pagedattention; @callo]

循环层的状态不能简单通过缩短逻辑序列恢复。若候选计算已经把被拒后缀写入单一递归状态张量，旧接受边界的信息可能丢失，因此需要快照、检查点重放或接受路径的紧凑因子。HybridSpec 针对链式 GDN 验证，保留按因果次序组合的候选更新因子，并在路径已知后形成持久状态；Twig 将类似问题推广到树的祖先依赖，通过选中路径重建持久状态。二者降低或重新安排状态维护开销，但分别支付链形三角表示、树索引、临时缓冲及重建费用；整个模型的因果层间依赖并未因最后提交路径可压缩而消失。[@hybridspec; @twig]

接受决定与物化时点还可以分离。vLLM RecoverSSM 的开放提案将部分已接受输入保留为 pending，下一次验证前再重放并处理退出 runner 的边界。这种表示把当前轮的状态恢复费用转移到后续消费者，其正确性依赖请求世代、检查点、输入日志及有效位置的一致性，并要求在 slot 复用与请求结束时恰当地处理未物化状态。对混合 Transformer–GDN 模型，正确性还需同时覆盖 KV、递归与卷积状态。[@pr-recover; @hybridspec; @twig]

## 检查点、输入缓存与接受路径重建 {#state-representations}

令某层的循环更新为 $S_{i+1}=f(S_i,x_i)$。以相同的起点和一组候选输入，可以构造三种物化策略。逐位置快照在求值期间生成每个可能边界的完整状态，提交时直接选择，空间和写入随候选数提升。检查点加近期输入通过重放或输出专用公式恢复相同语义，成本受输入缓冲长度、刷新频率及消费者位置影响。因子化方法保留能表示分支更新的紧凑量，在接受路径已知后批量重建，避免为每个候选长期保留完整状态。树形候选还需显式描述父节点与最终选中路径，顺序检查点的回退指针不足以表示任意分支。[@replayssm; @hybridspec; @twig]

ReplaySSM 将可见状态表示为慢更新的检查点与近期输入缓冲，常见非刷新步可直接计算需要的输出，丢弃后缀时移动有效边界。刷新折叠的是已提交输入，不能将仍待验证的输入提前写成唯一检查点。其公开说明和预印本给出了输入缓存、输出求值与刷新成本的不同时间分布。HybridSpec 将 GDN 的候选更新组织为三角计算并为最终接受前缀重建，Twig 进一步在树上分解祖先依赖。对比三者时，应该在相同接受路径长度、精度和缓存预算下观察平均延迟、被拒长尾及跨轮累积数值误差；不能只对比一次重建 kernel。[@replayssm-blog; @replayssm; @hybridspec; @twig]

延迟物化可以提升重叠，但将义务转移到下一位消费者。例如当前轮先发布已接受 token 的数量，而设备只保留旧 checkpoint 和接受输入日志。只要下一轮启动时读到一致的 checkpoint、日志范围与目标前缀，就能在读前补上计算。若状态要迁移、交换缓存或重新分配请求槽，接收方也必须理解这种表示，或者在出队边界先完成物化。对混合模型，应分别核对 attention、SSM、短卷积和草稿上下文，局部一层正确不自动闭合整模型的状态契约。[@hybridspec; @twig; @pr-recover; @pr-d2h]

Table: 表 4　接受后状态的表示、提交位置与约束。

| 状态表示 | 提交动作 | 需要追踪的成本和边界 |
|:--|:--|:--|
| 分页 KV [@pagedattention; @specinfer] | 选取接受路径上的行并发布有效长度和块映射 | 部分页有效边界、暂存分支清理、跨请求块引用 |
| 逐位置循环快照 [@hybridspec; @replayssm] | 从已求值位置选择完整状态 | 多位置实体写入、快照容量、误选非接受位置 |
| 检查点与输入缓冲 [@replayssm; @pr-recover] | 推进已接受输入边界，必要时再折入检查点 | 刷新或下一轮重放、消费者等待与迁移语义 |
| 块或树的紧凑因子 [@hybridspec; @twig] | 根据最终路径重建接受状态 | 因子暂存、路径索引、精度与综合提交时延 |

## 固定 vLLM 与 Ascend 路径 {#fixed-runtime}

在 vLLM 固定提交 `0fc695fc6d1d82e9a5ac6835ac8e4e1c83703665`，调度器的 `schedule` 在 token 预算和请求进度下安排本轮工作，`update_draft_token_ids` 接收候选。GPU MRV2 的 `BaseSpeculator.propose` 接收批次、目标隐藏特征、接受或拒绝计数及抽样信息。Runner 的 `prepare_inputs` 和 `execute_model` 准备 token 行、位置和 KV block tables。目标 `sample` 在存在草稿时调用 `rejection_sampler` 并传入 draft logits，得到抽样与拒绝计数。`postprocess_sampled` 首先通过 `post_update` 更新 token、计算进度和请求统计，再调用 `model_state.postprocess_state` 处理模型专用状态。采样配置中还存在 synthetic 方法，调试模式产生的接受计数不提供分布保证。以上证据定位到 MRV2 的相关代码路径，整体功能入口以官方文档补充。[@vllm-pin; @vllm-scheduler; @vllm-sampler; @vllm-draft; @vllmdocs]

vLLM-Ascend 固定 `5cb98caaadeff42b5b62b996e34bb2aaa29d20fd` 的 MRV2 在继承提交路径后增加一条 CPU 消费链。独立复制流等待当前生产者流，异步回传 `num_computed_tokens` 并记录 event。`_update_seq_lens_cpu` 在读取已缓存请求对应的槽位前同步该 event，再加上本轮调度的 token 数形成 CPU 长度元数据。这表明，D2H 字节数虽小，消费者能否提前继续仍由等待集决定。后续 #21430 提议将复制发起移到设备状态提交之前，保留上一计数写入的依赖，并主张新请求写槽与旧请求 CPU 消费槽可以分开。该排序的可移植条件是生产者、消费者和槽位的真实依赖成立，不能只根据调用位置提早就判定正确。[@ascend-pin; @pr-d2h]

图重放降低潜在的提交开销，能覆盖到哪一步取决于 shape、资源寿命、拷贝及后端支持。vLLM #63421 把 adaptive verification 的预算选择替换为预热的一次 Triton launch，改的是调度开销和编译停顿。Ascend #19512 的 DFlash2 Full ACLGraph 覆盖 MRV2 下的草稿前向、候选选择和草稿缓存更新，其作者评测对应 Qwen3.8-27B-W8A8、4×910B4 与 TP4。#20254 仍在评审，针对 rejection sampling 的 host launch 和图重放，特殊采样路径仍有 fallback。这些版本各自落在决策、草稿或采样热路径，具体可组合性须按目标模型、量化、图模式及硬件检查。这些实现分别面向不同的量化、模型并行与硬件配置，其收益范围由相应执行条件确定。[@pr-av; @pr-graph; @pr-sampling; @ascenddocs]

SGLang 为候选验证与状态提交提供了另一实现对照。其文档明确，随机验证模式与链宽、硬件后端和分离部署相关。在 SGLang 固定 DFlash runner 中，`_chain_accept_indices` 生成接受行索引，目标状态有独立的 `_update_target_mamba_state_after_verify` 路径。固定实现还会在部分设备缺乏非贪心验证时产生贪心 fallback 提示，明确指出请求分布无法保持。应用最新文档选项时须再查部署版本。[@sglangdocs; @sglang-pin]

## 请求生命周期中的读写边界 {#lifecycle}

固定 Runner 的计数依赖说明，提交的负载既包括张量工作，也包括跨层元数据。一次典型执行从 Scheduler 安排候选行起，接着由输入路径建立位置和块表，由 verifier 生成目标 logits 和接受计数，再由 postprocess 更新请求的有效状态。计数生产在目标采样之后，计数可用于下一轮 CPU 形状准备，与循环状态何时被下一次目标前向读取是两条依赖。若计数传输排在等待所有状态写回的流后，准备阶段可能等待不相关工作。若实现提前传输，须证明传输期间不会覆写当前读者所需的槽。相同 D2H 大小在两种时序下可以有不同的可见时延。[@vllm-pin; @vllm-scheduler; @ascend-pin; @pr-d2h]

图重放增加了地址与范围的一致性要求。捕获时通常固定部分缓冲的地址及可容纳 shape，运行时再更新有效行、位置映射或采样参数。将一个请求验证完毕后的候选长度用于选下一轮图，要确认图内消费的是对应轮次的新值；padding 行能否影响实际采样或写回取决于后端掩码和计数。TP/EP 下，计数和接受路径还必须在需要共享它们的 rank 间一致，空请求行也不能漏掉相应的通信参与条件。验证这些职责可分别观察实际图命中、输入刷新、采样与提交事件，以及请求上的 token 差分。[@flashinfer; @vllm-pin; @ascend-pin; @pr-graph]

Device sampler、图重放、草稿生成和请求调度能够独立演进，但一次推测轮次仍须在这些接口间保持统一的候选分布、请求状态与版本语义。精确随机采样要求 Drafter 提供相应的条件提议概率，并由实际采用的 Verifier 计算接受与纠正分布；图模式和设备后端则决定这些计算能否在同一执行路径上完成。以固定请求轨迹对照 token、accept/reject 计数、状态事件及目标输出，再比较图/eager 与并发配置，可以区分抽样语义、状态管理和实际执行成本的作用。[@vllm-sampler; @sglang-pin; @sglangdocs; @ascenddocs; @pr-sampling]

# 在线服务中的预算、资源与重叠 {#serving}

单轮局部优化进入连续批处理后，额外草稿、临时状态和验证工作会与其他请求共享容量、计算和通信资源。异步也可能用预计算浪费换取较短等待。本节将每请求进度、批次吞吐和 SLO 达成分开，解释服务负载为何可能改变推测优化的收益方向。[@illusion; @smartspec; @forespark; @pipespec]

## 负载如何改变推测的边际成本 {#serving-cost}

推测的在线成本取决于额外工作是否占用服务的实际约束资源。草稿权重、KV、循环状态和图池减少可以驻留的请求容量；验证扩展又可能改变本轮 Target 的查询行、专家集合与通信等待。如果 decode 与 chunked prefill 共用执行窗口，为某个请求提高接受长度可能推迟另一个请求的首 token。因此，单请求 TPOT 与批量吞吐、TTFT 和 SLO Goodput 不必同向变化；必须在明确请求到达方式和相同硬件、缓存预算下解释收益。[@illusion; @smartspec; @adaserve; @forespark]

局部优化进一步揭示了指标分母的重要性。Weights That Stay 让串行草稿 head 的词表投影分片尽量驻留于 on-chip 存储，并以 persistent kernel 减少重复访存与 launch；其作者在单 H100、SGLang、Qwen3-4B/8B 的特定 Markov 草稿配置下分别报告最高 12.3%/8.6% 的客户端吞吐提升。草稿 KV 量化研究则给出反向证据：在 Qwen2.5-3B/1.5B 的 batch-one 原型中，packed K4V4 降低了草稿缓存字节，但报告的整体峰值分配未同比下降、1K/16K 端到端平均时延反而更长；该表还指出 batched verifier 与顺序参考的 greedy token 不一致。两项研究的硬件与任务不可直接配对，但共同说明减少某个组件的字节或时间，只有释放真实瓶颈且保持输出合同，才可能兑现为服务收益。[@weights; @draftkv]

## 请求级门控与服务目标 {#online-control}

连续批处理允许就绪请求在轮次之间加入或退出。若候选的目标验证占用了可调度的 token 位置，某个请求更低的单位 token 时间可能以别人更久的等待为代价。SmartSpec 将目标设为每批单位时间有效输出，并在当前负载下联合考虑不同请求的推测深度和是否采用普通解码。AdaServe 则根据每个请求的 SLO 选择树内节点，优先满足不同的进度需求，再将剩余预算用于提高吞吐。ForeSpark 面向块并行草稿，提前对草稿生成与后续验证联合分配。三者分别着重全批有效产出、请求异质目标与实际生成工作量，评估时也需要不同的负载控制。[@smartspec; @adaserve; @forespark]

请求级 SLO 评价应同时明确到达 cohort 与完成计数窗口。设 $A_W$ 为长度 $W$ 的到达观察窗内进入系统的请求集合，$C_W$ 为稳态完成观察窗内完成的请求集合。若一个请求的 TTFT 与 TPOT 均不超过阈值 $\tau_f,\tau_p$，且按评测规定正常完成，则记 $I_i=1$，否则为零。到达 cohort 的达成率在该 cohort 的所有请求完成、超时或按规则终止后计算，窗口内达标完成速率则按完成窗计量：
$$
\operatorname{attainment}(A_W)=\frac{\sum_{i\in A_W}I_i}{|A_W|},
\qquad
\operatorname{SLO\ goodput}(W)=\frac{\sum_{i\in C_W}I_i}{W}.
$$
两个分子的集合不同，有限测量窗口中不能将二者无条件相等；在稳定到达、经过预热和排空条件说明的长期观察中，二者才可能通过请求率联系。不同论文还将 goodput 用作有效 token 速率或满足给定达标率的最大请求率，必须保留各自定义。取消、拒绝服务、超时以及未完成请求不能被静默移除，以免人为改善长尾。[@smartspec; @adaserve; @forespark; @distserve]

长上下文的运行环境需要把多种资源放回同一图景。目标验证可能跨 query 共享前缀访存，而对草稿使用稀疏历史有机会进一步减少读流量。对缓存受限负载，草稿 KV、图池或临时循环状态降低可容纳批量，即便每轮时间下降，也可能增加换页或请求等待。对于受功率约束的部署，单次目标权重访存可以同时由 batching 和推测摊销，二者优化的能耗成分可能重叠；还要计入草稿与额外查询的能量。已有能耗测评通过 graph 和 batch 对照揭示了这种依赖，实测边界是所列 GPU、模型和输入。[@magicdec; @draftkv; @hybridspec; @energy]

## 跨阶段和跨设备的重叠 {#overlap}

相邻阶段的空闲不能直接通过把草稿放到另一条 stream 消除。草稿不知道本轮接受边界时，下一轮输入在语义上未确定。PipeSpec 用多级模型构成异步层级，使阶段可以超前处理候选，利用显式验证和回滚修正错路。Speculative Speculative Decoding 从另一方向为本轮若干可能结果提前构造后续草稿，最终按已验证前缀查命中；miss 需要新的草稿或回退。不同设计的共同点是把部分等待换成条件计算，差异在于额外工作占用的设备和回滚边界。[@pipespec; @ssd]

异步路径的收益要结合失配分析：若本轮结果稳定且草稿资源独立，准备大概率后继可隐藏等待；若候选分支太多、目标和草稿争抢带宽或 miss 频繁，预计算会增加总设备时间和状态峰值。跨节点还需支付结果通知、草稿缓存定位和传输。Prefill–decode 分离情景中的 Callo 使用已有失效 KV 作为提议来源，在精确 KV 到位后做最终验证，其重叠机会来自跨阶段传输等待，与对验证结果提前备份不同。特定硬件上的过载结果不能与多设备流水收益在不记资源的情况下直接排序。[@ssd; @pipespec; @callo; @distserve]

实测应给出两层基线。第一层在同一目标、同一数据和生成语义下比较同步推测与异步方案，隔离等待和额外工作。第二层固定总硬件预算，将草稿卡、目标卡、跨节点通信、内存驻留与可用的 AR 副本数一起比较。服务净收益应包含提前工作中实际复用的比例、放弃计算、回退等待和输出性能，并区分同服务所需设备数、每卡吞吐和受 SLO 约束的整体产出。这两层证据分别回答关键路径能否缩短和部署是否值得。[@ssd; @pipespec; @distserve]

Table: 表 5　服务控制器按照动作作用点的比较。

| 决策粒度 | 代表机制 | 主要观测和失效边界 |
|:--|:--|:--|
| 草稿位置与停止时机 | DISCO、ForeSpark [@disco; @forespark] | 置信和块形状，需核对少生成能否落实为少执行 |
| 请求或批次的验证预算 | SmartSpec、D-Cut、AdaServe [@smartspec; @dcut; @adaserve] | 前缀存活、批次价格和 SLO，跨请求选择依赖可执行 shape |
| 目标内部分段验证 | HybridSpec [@hybridspec] | 首层路由和后续成本，受条件执行和因果不变性约束 |
| 跨轮和跨设备投机 | PipeSpec、SSD [@pipespec; @ssd] | 等待、分支命中和状态过期，收益须计额外资源 |
| 部署配置与回退 | TableTune、SpecSearch [@tabletune; @specsearch] | 实测 shape、显存上限，版本和 workload 迁移需要复核 |

# 实验证据的可比性 {#evidence}

一项机制在源码中实现、在微基准中更快与在真实服务中更快，需要不同的证据。目标、采样方式、TP/EP、图模式、请求到达和测量分母的差异，可能使看似相同的 speedup 不可比较。本节优先讨论匹配基线、配对消融、退化案例和相互作用，而不是建立跨论文最高倍率排名。[@illusion; @hybridspec; @forespark; @specsearch]


## 从候选、提交到服务收益的跨层综合 {#cross-layer-synthesis}

前文机制可以沿三条因果链综合，而不是仅归入新的技术类别。第一条是候选条件到真实 Target 工作：EAGLE 系列改善后继提议的信息质量，DFlash、DSpark 和树构造改变草稿的串行步与候选几何，TableTune 和 ForeSpark 则决定哪些逻辑行进入实际执行。只有当较好的提议转化为更少的目标轮数，或当候选剪枝转化为更少的真正设备操作时，接受概率与执行吞吐才会形成正向联系。该链条的必要观测是沿路径存活的候选、总验证行、填充后的设备形状及草稿与目标的关键路径费用。[@eagle3; @dflash; @dspark; @dforktree; @tabletune; @forespark]

第二条是验证语义到可持续目标状态。经典精确采样回答所选 token 是否来自正确的目标分布；SpecInfer 的树路径、HybridSpec 的 GDN 因子与 Twig 的树形状态重建则回答选中路径如何成为可供后续消费的执行状态；RecoverSSM 的延迟重放和 Ascend 的计数回传进一步暴露逻辑接受、状态物化与跨轮可见性不在同一个时刻。因而，验证器的正确性测试需要与状态版本、请求槽位及下一轮输出差分相连。只对当前轮输出做逐 token 检查，不能覆盖被拒候选暂态污染下一轮的故障。[@leviathan; @specinfer; @hybridspec; @twig; @pr-recover; @pr-d2h]

第三条是局部计算成本到共享服务资源。Weights That Stay 主要减少特定串行草稿 head 的访存和发射，草稿 KV 量化主要缩减候选状态字节；SmartSpec、AdaServe 和 ForeSpark 则改变请求间的验证预算与达标目标。三类工作可以互补，但各自优化的资源并非等价：减少草稿字节未必释放 Target KV 容量，降低单轮延迟也不一定提高开放到达下的可承受请求率。本文据此将结果证据分为机制可实现、局部测量和服务端到端三个层级，并只在同一分母和资源边界下形成性能排序。[@weights; @draftkv; @smartspec; @adaserve; @forespark]

这三条链共同揭示推测加速的系统条件：**候选的逻辑价值必须经过符合目标语义的验证，转化为可供下一轮使用的执行状态，并在设备与共享资源约束下减少有效输出的关键路径成本**。当生成、验证、状态发布或服务调度引入额外等待和无效工作时，接受长度单独增长便不足以解释最终收益。

## 对齐分母与匹配基线 {#comparison}

经验比较需要先确定输出、工作与时间的计数单位。草稿 acceptance rate、每轮接受草稿数、每轮提交输出数、目标实际查询行与服务 token/s 测量不同对象；即使使用相同名称，论文对 bonus token 和拒绝纠正 token 的计数也可能不同。例如 HybridSpec 的 AL 与 DForkTree 的 $\tau$ 包含目标额外输出，而某些草稿训练指标只统计接受的候选位置。ForeSpark 的内部有效工作 goodput 与开放到达条件下 TTFT、TPOT 同时达标的请求比例及容量边界也不相同。比较前应先给出各指标的分母、窗口与停止条件，不能以一次验证进度替代客户端完成时间。[@hybridspec; @dforktree; @forespark; @illusion]

可比基线由要识别的机制决定。评估 Drafter 应匹配 Target、Verifier、候选几何及采样，评估动态预算应保留相同 Drafter 与状态路径，评估 Serving 净收益则需要同配置 AR、调优的固定推测与可运行的动态控制作为强参照。开放到达、固定并发、离线 batch 的排队和资源利用口径不同，模型、精度、TP/EP、图模式、缓存与请求长度又会移动收益反转点。因此，证据表不跨工作合成加速排名，而逐项记录可支持的判断；同一工作中出现的退化、数值分歧与资源副作用也属于需要保留的结论。[@illusion; @tabletune; @specsearch; @forespark]

Table: 表 6　代表性推测解码研究的实验设置、性能结果与适用范围。

| 工作与定位 | 对照条件 | 可支持的判断 |
|:--|:--|:--|
| HybridSpec Table 1、Appendix E [@hybridspec] | SGLang 0.5.16、A100 80 GB、三个 Qwen3.5/3.6 GDN–MoE 与官方 DFlash，SPEED-Bench 主表 280 测试请求，单请求贪心 | 按类别汇总的 post-prefill speedup 为 AR 的 1.75–1.88 倍。附录另有温度 1 两组模型与四并发闭环，覆盖有限 |
| ForeSpark Figures 8–9 [@forespark] | vLLM 0.30.0，Qwen3-14B TP8 H100；GLM 系列 TP8+EP8 B200。ShareGPT，主结果为贪心 | Qwen3-14B 在 ShareGPT-E2E 开放到达下，90% 达标时的请求率为 DSpark 的 1.51 倍，为最强基线的 1.20 倍 |
| TableTune Table 1、§6 [@tabletune] | H100，vLLM V2，闭环模型及草稿组合，对照逐负载最佳固定长度 | 五组测试中四组的校准表达到最佳固定基线吞吐的至少 94%。图模式影响表的可转移性 |
| Twig §§VI–VII [@twig] | SGLang，A100/GB10，含 Qwen3.5 和混合模型的树验证；有离线和 Open-SWE-Traces 在线案例 | 分开测树 verifier、整模型与在线尾部时延。收益依赖状态 kernel、预算和端到端调度组合 |
| SpecSearch Figure 2、§V [@specsearch] | Qwen3-4B、RTX 5090，vLLM AR 与 DFlash 配置，短输出、不同并发 | 在该 sweep 中 DFlash 吞吐由并发 2 的 AR 3.50 倍变成并发 64 的 0.76 倍。设备与内存校准决定排序 |
| Draft KV quantization Table 8 [@draftkv] | Qwen2.5-3B/1.5B，1K/16K、256 输出、batch one，packed K4V4 与 BF16 SD | 草稿缓存字节下降，但整体峰值分配未同步变化，端到端解码时延增加；说明缓存压缩与计算价格之间存在权衡 |

HybridSpec 的 Table 1 和 Table 3 给出一个直接的反例：Qwen3.6-35B-A3B 的主表平均提交量从 vanilla DFlash 的 4.79 降至 4.57，平均 AR 归一化速度却从 1.37 增至 1.83。这里的收益来自少验证与更高效的循环状态处理的组合。与此同时，附录 E.7 的同模型四客户端运行，整体吞吐只比 vanilla DFlash 高约 10%，批中请求共用一个窗口长度。对比两者应保留负载、基线和分母，避免把单请求加速推广到服务 SLO。[@hybridspec]

## 消融能够回答的因果问题 {#ablation-reading}

HybridSpec 的配对消融可以拆开窗口、路由与状态恢复的效果。同一 Qwen3.6-35B-A3B 设置下，Table 3 中完整方案的平均验证窗口为 6.2，vanilla DFlash 为 16；平均接受长度下降约 5%，作者报告的 pooled decode 时间每轮从 23.0 ms 降到 16.3 ms。这个量级差距支持“少做目标验证能覆盖少提交”的解释。同表还比较完整方案和长度 7 的校准静态方案，静态方案保留专用 GDN kernel，但因撤掉动态长度同时移除了依赖它的路由修正和分段验证。由 1.54 倍到 1.83 倍的差异反映该组策略的联合价值，不能全算给长度预测器。[@hybridspec]

若只看路由修正，nominal-only 对照保留两阶段结构，以是否处理额外候选及决定保留为主要差别。相比完整方案，该变体的 AR 归一化 SR 为 1.73 倍；将 GDN kernel 替换回默认实现的变体为 1.74 倍。这些是完整设置上的边际对照，组件贡献存在交互，不能将倍率相乘推算总收益。相同论文的 GDN 微基准从预先计算的投影开始，其 1.54–4.04 倍属于较长窗口下 GDN 验证与接受态重建的局部测量，目标其他层、草稿和调度未进入这个分母。[@hybridspec]

Table: 表 7　HybridSpec Table 3 的 Qwen3.6-35B-A3B 对照。数字为论文报告值，SR 的共同分母为 AR 解码。

| 方案或替换 | 平均验证窗口 | 平均 AL | SR |
|:--|--:|--:|--:|
| Vanilla DFlash | 16 | 4.79 | 1.37 倍 |
| 固定 16，专用 GDN kernel | 16 | 4.77 | 1.46 倍 |
| 校准静态 7，专用 GDN kernel | 7 | 3.99 | 1.54 倍 |
| Nominal-only，两阶段 | 6.1 | 4.48 | 1.73 倍 |
| 完整窗口策略，默认 SGLang GDN kernel | 6.2 | 4.51 | 1.74 倍 |
| HybridSpec | 6.2 | 4.57 | 1.83 倍 |

同一工作下，温度 1 的 Appendix E.6 与贪心主表使用不同抽样设定，应各自相对同设定 AR、DFlash 解读。Appendix E.7 的四并发 greedy 试验给出约 1.10 倍 DFlash 吞吐，批级共用窗口的策略空间与逐请求选择不同。同时，省去逐 token 循环快照会释放缓存空间；在这一设置下，显存收益和调度收益共同出现。推广到大并发时需在同一显存预算下比较吞吐与长尾，并核对能否复用目标和草稿模型、精度及图模式。[@hybridspec]

ForeSpark 对照将在线问题进一步分解。Figure 8 用匹配每用户生成速率来看总吞吐，Figure 9 用开放到达和指定 TTFT/TPOT 阈值来看服务容量。Qwen3-14B TP8 对 DSpark 的 1.51 倍是后者在 90% 达标条件下的请求率比；相对该设置最强基线为 1.20 倍。长历史与重载进入同一批时，草稿生成和目标验证多算的代价不同，因此比较应使用对应曲线区间。若只引用低并发 token/s 峰值，将无法回答多请求共享时是否提高可服务到达率。[@forespark]

另外，有些结论只能在不同工作之间做机制对照。SpecSearch 的同硬件并发扫描说明一个配置可以跨越收益反转点。Draft KV 量化的设备原型显示缓存字节减少可能与总峰值不变且整体运行变慢同时存在。TableTune 则通过图模式与固定长度对照说明执行器也会移动反转点。这三个结果分别改变负载、状态精度及执行形状的代价，彼此不能作为性能复现。它们共同约束的是解释：应给出实际有效进度、形状、KV/图预算和状态维护分项，才可能定位差异来自哪个边界。[@specsearch; @draftkv; @tabletune]

## 近期研究的机制演进 {#november}

面向并行草稿的新近研究将候选生成与目标预算的优化进一步耦合。ChainFlow、DSpark 和 Domino 分别从少步候选生成、轻量因果校正和训练协调改善块内依赖；DForkTree 与 D3Tree 将并行产生的位置候选组织为具有分叉和节点存活信息的树。它们的共同问题是，减少草稿的串行深度之后，如何在有限的目标计算预算内恢复有价值的条件依赖。ForeSpark 进一步把生成前的预算与生成后的验证预算联合建模，说明候选构造与目标查询形状需要协同选择。[@chainflow; @dspark; @domino; @dforktree; @d3tree; @forespark]

另一组工作将优化目标从接受长度扩展到完成轮数、状态恢复与部署成本。REAL Loss 与 EDR 分别面向接受轨迹和完成所需轮数调整草稿训练目标；HybridSpec 与 Twig 将混合模型的循环状态表示纳入验证设计；SpecSearch 则按硬件与并发条件选择推测配置。与此同时，Weights That Stay、草稿 KV 压缩、Hybrid Spark 和 Callo 展示了词表投影驻留、状态存储、提议源切换及跨阶段复用等执行选择。这些研究共同表明，推测解码的有效优化空间已经由局部提议质量延伸到状态生命周期及服务资源配置。[@realloss; @edr; @hybridspec; @twig; @specsearch; @weights; @draftkv; @hybridspark; @callo]

# 开放问题与可检验研究方向 {#directions}

现有研究已经提供训练接受目标、动态预算、路径状态重建和请求级控制等解法。剩余研究问题应限定为这些机制在同一执行与资源边界下尚未解决的组合条件，而非将既有方案重新命名为新方向。以下每项问题均给出相近工作、可比较的强基线及可能证伪的结果。[@realloss; @hybridspec; @twig; @forespark]

## 状态恢复何时应立即发生 {#deferred-commit}

HybridSpec 的紧凑 GDN 因子、Twig 的树形路径重建和 ReplaySSM 的检查点—输入缓存已经提供了不同的状态保存策略；RecoverSSM 提案进一步展示了将部分状态物化推迟至下一次消费的接口。因此，这里的剩余问题不是“能否延迟提交”，而是**在真实请求生命周期中，何种状态债务可以安全跨轮保留**。请求取消、前缀缓存共享、slot 复用和图/eager 交替会产生与当前验证器不同的消费者，它们可能要求在正常下一轮到来之前得到完整状态。[@hybridspec; @twig; @replayssm; @pr-recover]

一个有界假设是：若运行时显式携带 checkpoint 身份、已提交输入日志、有效边界和请求世代，并在所有不理解 pending 状态的消费者之前建立物化屏障，则可以在部分负载下把原本暴露的当前轮恢复时间移出关键路径。对照应同时包含部署已有的立即重建、检查点重放、接受路径紧凑因子及其可用的延迟实现，并匹配模型、验证结果与额外缓存容量。测试轨迹需覆盖首次拒绝、末位拒绝、全接受、EOS、取消、缓存交换、请求迁移和复用槽位；每个情形均对下一轮 Target logits、KV/循环/卷积状态及跨 rank 的索引做差分，而不只比较当前轮 token。[@hybridspec; @twig; @pr-recover]

应报告前台恢复等待、后续消费者补算、总设备工作、pending 状态峰值、正确性差分及回退次数。若所有延迟工作最终仍位于相同的消费者关键路径，或增加的状态存储导致更频繁的请求驱逐，则即使某个 commit kernel 局部变快，假设也不成立。该方向的潜在贡献是可组合的状态生命周期契约与可测量成本，而非重新实现一个已知的 checkpoint 算法。[@replayssm; @hybridspec; @pr-d2h]

## 路由与资源信息能否改进批内选择 {#routing-aware-scheduling}

TableTune 已以实际图形状和批大小构造成本表，ForeSpark 已协调 Draft 与 Verify 的预算，EVICT 和 HybridSpec 也分别在目标前及第一个路由点引入 MoE 成本信息。因此，“动态选择窗口”或“路由感知验证”本身不构成新贡献。剩余问题应限定为多请求 TP/EP 情形：**每 rank 的实际专家并集、负载偏斜与通信等待，是否包含形状成本表未能预测的增量信息**？这只有在目标执行器提供相应可观测性、且裁剪能够改变实际 expert work 时才有研究价值。[@tabletune; @forespark; @evict; @hybridspec; @moebytes]

强基线应在同一 Target–Drafter、采样规则、图候选集与总显存预算下同时实现：调优固定窗口、TableTune 式形状选择、ForeSpark 式请求级联合预算，以及在支持时加入 EVICT/HybridSpec 的已有路由选择。新方案只能增加已有基线没有使用的 rank-aware 代价信息，而不能暗中替换 Target kernel 或提高额外内存容量。分别在 decode-only、chunked-prefill 混合、不同历史长度和路由偏斜条件下测量候选到达率、实际专家字节、all-to-all 等待、重排控制时间及 SLO。[@forespark; @hybridspec; @moebytes]

若路由特征在留出请求或模型上不能稳定提高真实成本预测，或者它虽减少理论 expert bytes，却因 padding、graph bucket 和通信同步而没有缩短关键路径，就应接受形状表已经足够有效的结论。针对 Ascend 的探索尤其应先验证 fixed pair 上 AR、SpecDec 正确性、TP/EP 与目标图模式的支持；不能把 GPU 上的专家计时直接视为 910B2 的可迁移收益。[@ascend-pin; @tabletune; @specsearch]

## 训练目标能否对应服务效用 {#training-to-serving}

改善草稿的 token 预测误差、单轮接受长度和最终服务指标，是三个相关但不同的学习目标。DistillSpec 讨论分布对齐，REAL Loss 针对实际存活路径的接受目标，EDR 则从完成输出需要的推测轮数分析损失；ForeSpark 和其他 Serving 控制器还会按照当前负载选择可生成和可验证的位置。由此产生的具体问题是：**在位置成本不均、候选预算可变的系统中，训练所增加的接受机会是否真正位于会被执行、且价格值得支付的路径上**？[@distillspec; @realloss; @edr; @forespark]

可以固定 Target、Verifier、部署引擎、训练数据与训练计算资源，比较 token likelihood、常用接受长度目标、REAL Loss、EDR 以及一个使用实测边际成本作为权重的候选训练目标。最后一种是待验证假设，不能写为已有工作已经证明的模型。首先比较真实采样与推测轨迹的分位置存活曲线、候选条件分布和数值差分，再在固定窗口、动态窗口与服务到达轨迹中测量草稿耗时、Target 查询形状、完成轮数及 SLO；训练样本之外的长度和任务分布应单独留出。[@leviathan; @realloss; @edr]

如果训练收益集中在服务策略很少允许验证的深层位置，或更长的串行草稿抵消轮数下降，则即使离线 EAL 改善，也不足以支持服务收益。随机提议经数据依赖策略筛选还可能改变真正送入 Verifier 的分布，必须按第五节的 fidelity 条件重新检查输出概率。本方向的贡献应是接受路径、执行成本和学习目标之间的可验证联系，而不是以新的 loss 名称替代完整的 Serving 对照。[@realloss; @forespark; @leviathan]

## 资源预算内的推测并行化 {#resource-budget}

PipeSpec 与 Speculative Speculative Decoding 已探索跨阶段超前计算，通过预先准备可能的后继减少等待；Serving 引擎的 continuous batching 则能够用其他就绪请求填补部分同设备空隙。由此，异步推测的系统问题不是“是否允许并行”，而是**已有空隙是否值得用额外的草稿状态和分支计算购买更短的用户关键路径**。同请求 latency 与固定资源下服务容量可能朝不同方向变化，尤其在高并发、多设备及低命中工作负载中。[@pipespec; @ssd; @distserve]

应在相同 Target、生成语义、总卡数和内存限制下比较最优同步推测、已有 continuous batching、同设备重叠、独立设备异步以及可用的 AR 副本扩展。对高命中与高 miss 两种后继分布、请求长度突变和 prefill 混合负载，记录实际复用的提前工作、被丢弃分支、状态存储、跨设备传输、GPU/NPU 忙时和每请求 SLO 达成。不同设计能够访问的目标前缀必须完全一致；提前准备的错误路径不得隐式作为合法缓存复用。[@pipespec; @ssd; @forespark]

若新增设备用于普通 AR 或同步服务副本能处理更多达标请求，或等待被隐藏的时间小于提前无效工作造成的资源拥塞，异步路线在相同硬件预算下就不具备部署优势。对异构设备和 Ascend 的迁移还应独立核对执行图、event、通信和状态所有权接口，不能把 CUDA stream 的局部重叠经验直接当作 NPU 资源隔离结论。[@distserve; @ascend-pin]

## 形状和工作负载迁移 {#transfer}

Sequoia、TableTune 与 SpecSearch 分别在树预算、批次长度和部署配置层面引入硬件成本信息。已有结果说明，实际计算形状会影响可取的推测预算，但并未保证某一平台的性能模型能够直接解释另一类目标模型或后端。剩余问题因而是**哪一组可观测量能在较小重新校准成本下预测收益反转点**，而非假定存在跨 GPU、NPU 和 MoE 架构都不变的最佳长度。[@sequoia; @tabletune; @specsearch]

可固定候选分布和验证语义，只改变 Target 架构、输入长度、并行布局、图模式或硬件，记录逻辑节点与实际查询行之比、KV/权重字节、专家偏斜、填充、图命中率、状态维护和主机等待。需要将训练条件与预测条件分开：在留出设备或新负载上，比较原配置直接复用、少量点位重新剖析、逐候选穷举或网格搜索的可行最优值，以及用跨平台特征估计的候选方案。所有策略在相同校准预算下评估，并计入测量和切换成本。[@tabletune; @specsearch; @moebytes]

若少量新平台校准即可覆盖主要差异，复杂的跨硬件模型没有实际必要；若候选本身的条件分布或 Target verifier 改变，原平台的收益曲线也可能失去可比基础。对 Ascend，必须先以准确的 vLLM–Ascend 固定版本验收 AR、SpecDec 输出正确性、模型并行配置和相关算子支持，再报告任何迁移后的性能观察。本研究方向最终要回答的是条件和成本可以迁移到什么程度，而不是给不同平台复制一个未经证实的速度倍率。[@ascend-pin; @vllm-pin; @sequoia]

# 结论 {#conclusion}

推测解码通过低成本候选减少目标模型的串行验证轮数，但被接受的 token、已合法物化的执行状态与实际节省的设备时间是三个不同结果。本文以模型因果关系、候选拓扑和真实执行形状为共同坐标，比较不同候选来源、验证规则、状态恢复与在线控制的作用位置。接受长度增长可以被额外草稿、无效查询行与状态发布成本抵消；已确认前缀也只有在下一轮消费者获得一致的缓存与元数据后才能持续推进。

跨工作综合得到三个相互关联的判断。首先，检索、特征复用、浅层路径、并行块和树构造优化不同的条件依赖与构造成本，不能仅按平均接受率比较。其次，自适应预算和目标内分段验证必须同时满足所声明的输出保证、状态契约以及真正少执行昂贵工作这一收益条件。最后，批次组成、graph bucket、内存驻留、专家路由与异步排队共同决定局部算法收益是否转化为 TTFT、TPOT、吞吐或 SLO Goodput。不同测量只有在同一语义、基线及资源边界下才具有可比性。

据此，状态延迟物化、路由与验证预算联合优化、服务效用导向的训练及受资源限制的提前推测，可以进一步形成有强基线和证伪条件的研究问题。这些方向以既有机制为基础，进一步研究状态、预算和共享资源的联合条件。可持续的推测加速最终取决于目标语义、合法执行状态与有效输出成本的协同优化。

# 参考文献 {.unnumbered #references}

::: {#refs}
:::
