# 面向大语言模型推理的推测解码优化研究综述 — editable source snapshot

Literature cutoff: 2026-11-24
Manuscript revision: zh-survey-final-20261124-webfix2

Markdown, TeX, Word, bibliography and referenced figures are editable.
The PDF and Word are separate renderings of the same manuscript.
Manual edits to either do not automatically update the other formats.

## PDF

Install XeLaTeX, ctex and the fonts specified in paper.tex. Run:

    xelatex -interaction=nonstopmode -halt-on-error paper.tex
    xelatex -interaction=nonstopmode -halt-on-error paper.tex
    xelatex -interaction=nonstopmode -halt-on-error paper.tex

## HTML

With Pandoc 3+, run:

    pandoc paper.md --citeproc --bibliography=references.bib --csl=numeric.csl --css=paper.css --metadata=link-citations:true --number-sections --standalone --mathml --embed-resources --output=paper.html

Formatting may differ from the frozen publication. Reimport the complete
reviewed outputs to obtain a new immutable version.
