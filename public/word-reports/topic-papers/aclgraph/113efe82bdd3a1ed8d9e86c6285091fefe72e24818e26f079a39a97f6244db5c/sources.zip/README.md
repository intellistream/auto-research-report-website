# 面向大语言模型推理的ACLGraph图执行技术综述 — editable source snapshot

Literature cutoff: 2026-11-15
Manuscript revision: R2.1-taxonomy-examples

This package contains only editable manuscript sources, bibliography, original
figures and formatting resources. It contains no model requests/responses,
authentication receipts, downloaded third-party full texts or author-workflow logs.

## Rebuild the PDF

Install XeLaTeX with ctex and the fonts named in paper.tex (replace unavailable
fonts explicitly). From this directory run:

    xelatex -interaction=nonstopmode -halt-on-error paper.tex
    xelatex -interaction=nonstopmode -halt-on-error paper.tex

The supplied paper.tex is independently editable and already contains the rendered
bibliography. references.bib is also supplied for bibliography editing. The original
figure PDFs are included; their editable TikZ .tex and SVG representations accompany
them. Recompile the figure .tex files with XeLaTeX if editing those diagrams.

## Rebuild HTML from Markdown

With Pandoc 3+ run:

    pandoc paper.md --from=markdown+citations+tex_math_dollars --citeproc --bibliography=references.bib --csl=numeric.csl --css=paper.css --metadata=link-citations:true --number-sections --standalone --mathml --embed-resources --output=paper.html

HTML uses native MathML and embedded images; no JavaScript or remote CDN is needed.
Markdown/BibTeX and TeX are separate editable representations: rebuilding from
Markdown does not incorporate later manual TeX-only edits. Tool/font versions may
change layout and bytes; reimport the completed outputs to obtain a new version.
This source snapshot does not state editorial acceptance or expert certification.
