"""Build portable v5 HTML with frozen numeric citations and native MathML."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

from bs4 import BeautifulSoup, Comment

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "_build_logs"
PANDOC = os.environ.get("PANDOC_BINARY", r"D:\learning app\Anaconda\Scripts\pandoc.exe")
EXPECTED_COLUMNS = [5, 4, 6, 9, 4, 4, 4, 4, 4, 4]
TABLE_LAYOUTS = [
    (True, [.13, .19, .40, .16, .12]),
    (False, [.13, .25, .29, .33]),
    (True, [.12, .14, .13, .13, .15, .33]),
    (True, [.32] + [.085] * 8),
    (True, [.16, .25, .27, .32]),
    (True, [.16, .25, .39, .20]),
    (True, [.16, .26, .38, .20]),
    (True, [.16, .25, .36, .23]),
    (True, [.17, .28, .35, .20]),
    (True, [.22, .23, .34, .21]),
]
FORBIDDEN = ("双平面", "平面 I", "平面 II", "T1-L", "T2-L")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pandoc(*args, text=None):
    LOGS.mkdir(exist_ok=True)
    temporary = LOGS / "native-tmp"
    temporary.mkdir(exist_ok=True)
    environment = os.environ.copy()
    environment.update(TEMP=str(temporary), TMP=str(temporary))
    result = subprocess.run([PANDOC, *map(str, args)], input=text, cwd=ROOT, env=environment,
                            capture_output=True, text=True, encoding="utf-8")
    if result.stderr:
        with (LOGS / "pandoc.log").open("a", encoding="utf-8") as log:
            log.write(result.stderr)
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout


def publication_ast():
    """Keep the matrix's group labels in its work column, yielding nine columns.

    This is a presentation-only change. No row, citation, capability, or group
    value is removed, and the original Markdown remains byte-identical.
    """
    ast = json.loads(pandoc("paper.md", "--from=markdown", "--to=json"))
    tables = [block for block in ast["blocks"] if block["t"] == "Table"]
    assert len(tables) == 10
    matrix = tables[3]["c"]
    assert len(matrix[2]) == 10
    matrix[2] = matrix[2][1:]
    for row in matrix[3][1]:
        row[1] = row[1][1:]
        row[1][0][4] = [{"t": "Plain", "c": [{"t": "Str", "c": "工作（分组）"}]}]
    count = 0
    for body in matrix[4]:
        for row in body[3]:
            cells = row[1]
            group = cells[0][4][0]["c"]
            cells[1][4][0]["c"] = [*group, {"t": "Str", "c": "："}, *cells[1][4][0]["c"]]
            row[1] = cells[1:]
            count += 1
    assert count == 33
    assert [len(t["c"][2]) for t in tables] == EXPECTED_COLUMNS
    return ast


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--html-only", action="store_true")
    args = parser.parse_args()
    source_hash = sha256(ROOT / "paper.md")
    mapping = json.loads((ROOT / "publication-reference-map.json").read_text(encoding="utf-8"))
    assert len(mapping) == 74 and set(mapping.values()) == set(range(1, 75))
    ast = publication_ast()
    pandoc("--from=json", "--to=html5", "--standalone", "--citeproc",
           "--bibliography=references.bib", "--csl=numeric.csl", "--metadata=link-citations:true",
           "--mathml", "--self-contained", "--css=paper.css", "--output=paper.html",
           text=json.dumps(ast, ensure_ascii=False))
    soup = BeautifulSoup((ROOT / "paper.html").read_text(encoding="utf-8"), "html.parser")
    for comment in soup.find_all(string=lambda value: isinstance(value, Comment)):
        if "html5shiv" in comment.lower() or "[if" in comment.lower():
            comment.extract()
    soup.select_one("header .title")["id"] = "paper-title"
    for heading in soup.select('h1[id^="section-"],h2[id^="section-"],h3[id^="section-"]'):
        heading.name = "h" + str(int(heading.name[1]) + 1)
    soup.find(id="references").name = "h2"
    for index, table in enumerate(soup.select("table")):
        columns = len(table.select_one("tr").find_all(["th", "td"], recursive=False))
        assert columns == EXPECTED_COLUMNS[index]
        if columns == 9:
            table["class"] = [*table.get("class", []), "wide-matrix"]
        table.wrap(soup.new_tag("div", attrs={"class": "table-wrap"}))
    for paragraph in soup.select("p"):
        text = paragraph.get_text(" ", strip=True)
        if re.match(r"^表\s*\d+[A-Z]?", text) and paragraph.find("strong"):
            paragraph["class"] = ["table-caption"]
        elif re.match(r"^(?:表注|注)[：:]", text):
            paragraph["class"] = ["table-note"]
    actual = {}
    for number, entry in enumerate(soup.select('#refs .csl-entry[id^="ref-"]'), 1):
        key = entry["id"][4:]
        actual[key] = number
        entry["id"] = f"ref-{number}"
        entry["data-source-key"] = key
    assert actual == mapping, "citeproc numbering differs from publication-reference-map.json"
    for link in soup.select('a[href^="#ref-"]'):
        key = unquote(link["href"][5:])
        link["href"] = f"#ref-{mapping[key]}"
        link["class"] = sorted(set(link.get("class", [])) | {"citation"})
    for citation in soup.select("[data-cites]"):
        keys = citation["data-cites"].split()
        citation["data-source-keys"] = " ".join(keys)
        citation["data-cites"] = " ".join(str(mapping[key]) for key in keys)
    identities = json.loads(pandoc("references.bib", "--from=biblatex", "--to=csljson"))
    assert len(identities) == 74
    for record in identities:
        entry = soup.find(id=f"ref-{mapping[record['id']]}")
        url = record.get("URL") or ("https://doi.org/" + record["DOI"] if record.get("DOI") else None)
        if url and not entry.select('a[href^="http"]'):
            link = soup.new_tag("a", href=url)
            link.string = "原始来源"
            entry.extend([" ", link])
    css = (ROOT / "paper.css").read_bytes()
    assert b"\\" not in css and b"@import" not in css.lower()
    for link in soup.select('link[rel="stylesheet"]'):
        link["href"] = "data:text/css;charset=utf-8;base64," + base64.b64encode(css).decode("ascii")
    images = soup.select("img")
    paths = re.findall(r"!\[.*?\]\((figures/fig[^)]+\.png)\)",
                       (ROOT / "paper.md").read_text(encoding="utf-8"))
    assert len(images) == len(paths) == 5
    for image, path in zip(images, paths):
        assert image.get("alt", "").strip()
        assert image["src"].startswith("data:image/png;base64,")
        assert base64.b64decode(image["src"].split(",", 1)[1]) == (ROOT / path).read_bytes()
    ids = [node["id"] for node in soup.select("[id]")]
    assert len(ids) == len(set(ids))
    assert all(unquote(link["href"][1:]) in ids for link in soup.select('a[href^="#"]'))
    assert len(soup.select('h2[id^="section-"]')) == 6
    required = [f"section-3-{n}" for n in range(1, 5)] + [f"section-4-{n}" for n in range(3, 7)]
    assert all(soup.find(id=anchor).name == "h3" for anchor in required)
    assert {h["id"] for h in soup.select('h4[id^="section-"]')} == {
        f"section-5-2-{n}" for n in range(1, 5)}
    assert not soup.select("script") and soup.select("math")
    assert not any(word in soup.get_text() for word in FORBIDDEN)
    assert not any(key.lower().startswith("on") for node in soup.find_all(True) for key in node.attrs)
    output = str(soup)
    assert not re.search(r"html5shiv|<script\b|@import\b", output, re.I)
    (ROOT / "paper.html").write_text(output, encoding="utf-8")
    (ROOT / "reference-identities.json").write_text(
        json.dumps(identities, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    assert sha256(ROOT / "paper.md") == source_hash
    report = {"citation_targets": 74, "reference_map_matches_probe": True,
              "chapter_headings": 6, "analytical_leaf_headings": 4,
              "figures": 5, "matrix_columns": 9, "matrix_rows": 33,
              "tables": 10, "broken_fragment_links": 0, "mathml": len(soup.select("math")),
              "html_bytes": (ROOT / "paper.html").stat().st_size,
              "html_sha256": sha256(ROOT / "paper.html")}
    (LOGS / "web-build-receipt.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if not args.html_only:
        from build_pdf import generate_tex
        report["latex"] = generate_tex()
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
