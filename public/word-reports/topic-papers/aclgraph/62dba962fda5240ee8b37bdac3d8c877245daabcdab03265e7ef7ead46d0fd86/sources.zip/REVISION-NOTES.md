# v5 publication build

Manuscript revision: v5-csur-20261124. Literature cutoff: 2026-11-24.

The PDF in this snapshot is compiled independently from `paper.tex` by XeLaTeX
and the TeX Live PDF backend. It is not an export of the Word document. No Word
automation or browser is part of this build. The generic README produced by the
read-only legacy importer describes an earlier Word-based workflow; the commands
and provenance in this file apply to v5.

- `paper.md`, `references.bib`, `numeric.csl`, and the retained reference template
  have not been edited. `publication-reference-map.json` freezes citeproc's 74
  entries in their final bibliography order.
- All five figure families carry numeric citations. Figures 1–4 include a source
  band associating references with the frozen nodes. Figure 5 prints the 28
  node citations in its existing right-hand citation regions.
- Table 4 contains 33 works and eight capability fields. Its original group
  field is retained inside the work cell in all three exports, giving the
  requested nine-column matrix without dropping any values or citations.
- Nine dense tables use landscape pages and repeated headers. Table 2 remains
  portrait. SHA-1 commit identifiers acquire break opportunities in TeX.
- DOCX uses the supplied v3 template, native equations, embedded PNG figures,
  explicit column grids, repeated headers, and three-rule tables. Local paths
  and bibliography/csl custom properties are removed from the package.

## Rebuild from the author draft

```text
python -B -X utf8 prepare_publication.py
python -B -X utf8 figures/scripts/render_all_figures.py --citation-map publication-reference-map.json
python -B -X utf8 build_web.py --html-only
python -B -X utf8 build_pdf.py
python -B -X utf8 build_word.py
python -B -X utf8 verify_publication.py
```

Figure regeneration reads the original specification and PR radar through the
explicit read-only paths in `figures/scripts/common_style.py`. Only the local
`draft/figures/` tree is writable during figure generation.

## Rebuild from the importer's curated source archive

The importer intentionally includes the rendered figure families and the
Markdown/TeX/Word sources, not all private build and verification tools.
`paper.tex` already contains its rendered bibliography and uses the included
vector PDF figures. Compile it twice with XeLaTeX. For HTML or editable Word:

```text
python -B -X utf8 build_web.py --html-only
python -B -X utf8 build_word.py --reference-doc paper.docx --output rebuilt.docx
```

`build_word.py` has no PDF-export option. DOCX has package/OOXML validation;
the four 180-DPI PyMuPDF previews validate the independently typeset TeX PDF.
