"""Build the editable v5 DOCX using Pandoc and portable OOXML repairs."""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import re
from zipfile import ZipFile

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt, RGBColor
from docx.text.run import Run
from lxml import etree

from build_web import ROOT, LOGS, EXPECTED_COLUMNS, TABLE_LAYOUTS, pandoc, publication_ast, sha256


def element(parent, tag, **attributes):
    node = parent.find(qn("w:" + tag))
    if node is None:
        node = OxmlElement("w:" + tag)
        parent.append(node)
    for key, value in attributes.items():
        node.set(qn("w:" + key), str(value))
    return node


def set_font(owner, size, chinese="宋体", western="Times New Roman"):
    owner.font.name = western
    owner.font.size = Pt(size)
    owner.font.color.rgb = RGBColor(0, 0, 0)
    rpr = owner._element.get_or_add_rPr()
    fonts = element(rpr, "rFonts", ascii=western, hAnsi=western, eastAsia=chinese, cs=western)
    for key in list(fonts.attrib):
        if key.lower().endswith("theme"):
            del fonts.attrib[key]
    element(rpr, "sz", val=round(size * 2))
    element(rpr, "szCs", val=round(size * 2))
    color = element(rpr, "color", val="000000")
    for key in list(color.attrib):
        if key != qn("w:val"):
            del color.attrib[key]


def paragraph_runs(paragraph):
    return [Run(run, paragraph) for run in paragraph._p.xpath(".//w:r")]


def configure_styles(doc):
    if "Research Reference" not in doc.styles:
        style = doc.styles.add_style("Research Reference", WD_STYLE_TYPE.PARAGRAPH)
        style.base_style = doc.styles["Normal"]
    for name in ("Normal", "Body Text", "First Paragraph", "Abstract"):
        if name in doc.styles:
            style = doc.styles[name]
            set_font(style, 11)
            fmt = style.paragraph_format
            fmt.first_line_indent = Pt(22)
            fmt.line_spacing = 1.28
            fmt.space_after = Pt(5)
            fmt.widow_control = True
            fmt.keep_with_next = False
    for name, size in (("Title", 20), ("Subtitle", 11), ("Heading 1", 14), ("Heading 2", 12), ("Heading 3", 11.5)):
        style = doc.styles[name]
        set_font(style, size, "宋体" if name == "Subtitle" else "黑体")
        style.font.bold = name != "Subtitle"
        style.font.italic = False
        style.font.underline = False
        fmt = style.paragraph_format
        fmt.first_line_indent = Pt(0)
        fmt.keep_with_next = True
        fmt.keep_together = True
        fmt.line_spacing = 1.1
        fmt.space_before = Pt(13 if name.startswith("Heading") else 0)
        fmt.space_after = Pt(7)
        fmt.alignment = WD_ALIGN_PARAGRAPH.CENTER if name in ("Title", "Subtitle") else WD_ALIGN_PARAGRAPH.LEFT
        properties = style.element.get_or_add_pPr()
        for tag in ("pBdr", "numPr"):
            node = properties.find(qn("w:" + tag))
            if node is not None:
                properties.remove(node)
    for name in ("Hyperlink", "FollowedHyperlink"):
        if name in doc.styles:
            doc.styles[name].font.color.rgb = RGBColor(0, 0, 0)
            doc.styles[name].font.underline = False


def format_tables(doc):
    repaired = 0
    for index, table in enumerate(doc.tables):
        n = EXPECTED_COLUMNS[index]
        grid = table._tbl.find(qn("w:tblGrid"))
        if grid is None:
            grid = OxmlElement("w:tblGrid")
            table._tbl.insert(1, grid)
        if not len(grid):
            for _ in range(n):
                grid.append(OxmlElement("w:gridCol"))
            repaired += 1
        assert len(table.columns) == n
        wide, weights = TABLE_LAYOUTS[index]
        total = round((Mm(297 if wide else 210) - Mm(47)) / 635)
        widths = [round(weight * total) for weight in weights]
        widths[-1] += total - sum(widths)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = False
        for col, width in zip(grid, widths):
            col.set(qn("w:w"), str(width))
        properties = table._tbl.tblPr
        element(properties, "tblW", type="dxa", w=total)
        borders = element(properties, "tblBorders")
        for edge in ("top", "bottom", "left", "right", "insideH", "insideV"):
            element(borders, edge, val="single" if edge in ("top", "bottom") else "nil", sz=12, color="000000")
        for row_index, row in enumerate(table.rows):
            row_properties = row._tr.get_or_add_trPr()
            for height in list(row_properties.findall(qn("w:trHeight"))):
                row_properties.remove(height)
            element(row_properties, "cantSplit")
            if row_index == 0:
                element(row_properties, "tblHeader", val="1")
            for col_index, cell in enumerate(row.cells):
                properties = cell._tc.get_or_add_tcPr()
                element(properties, "tcW", type="dxa", w=widths[col_index])
                padding = element(properties, "tcMar")
                for edge, amount in (("top", 60), ("bottom", 60), ("left", 55), ("right", 55)):
                    element(padding, edge, type="dxa", w=amount)
                shade = properties.find(qn("w:shd"))
                if shade is not None:
                    properties.remove(shade)
                cell_borders = element(properties, "tcBorders")
                for edge in ("top", "bottom", "left", "right"):
                    element(cell_borders, edge, val="single" if row_index == 0 and edge == "bottom" else "nil", sz=6, color="000000")
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                for paragraph in cell.paragraphs:
                    fmt = paragraph.paragraph_format
                    fmt.first_line_indent = Pt(0)
                    fmt.left_indent = fmt.right_indent = Pt(0)
                    fmt.space_before = fmt.space_after = Pt(0)
                    fmt.line_spacing = 1.12
                    fmt.keep_with_next = row_index == 0
                    fmt.keep_together = False
                    fmt.widow_control = False
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER if row_index == 0 or index == 3 and col_index else WD_ALIGN_PARAGRAPH.LEFT
                    # Permit character-level wrapping for long identifiers and commit hashes.
                    element(paragraph._p.get_or_add_pPr(), "wordWrap", val="1")
                    for run in paragraph_runs(paragraph):
                        set_font(run, 8.5 if index == 3 else 9)
                        if row_index == 0:
                            run.bold = True
    return repaired


def landscape_tables(doc):
    portrait = deepcopy(doc.sections[-1]._sectPr)
    def section_break(wide):
        paragraph = OxmlElement("w:p")
        properties = OxmlElement("w:pPr")
        paragraph.append(properties)
        section = deepcopy(portrait)
        page = element(section, "pgSz", w=16838 if wide else 11906, h=11906 if wide else 16838)
        if wide:
            page.set(qn("w:orient"), "landscape")
        else:
            page.attrib.pop(qn("w:orient"), None)
        element(section, "type", val="nextPage")
        numbering = section.find(qn("w:pgNumType"))
        if numbering is not None:
            numbering.attrib.pop(qn("w:start"), None)
        element(properties, "spacing", before=0, after=0, line=20, lineRule="exact")
        properties.append(section)
        return paragraph
    count = 0
    for index, table in enumerate(doc.tables):
        if not TABLE_LAYOUTS[index][0]:
            continue
        start = table._tbl
        previous = start.getprevious()
        if previous is not None and previous.tag == qn("w:p") and re.match(r"^表\s*\d", "".join(previous.itertext())):
            start = previous
        start.addprevious(section_break(False))
        end = table._tbl
        following = end.getnext()
        if following is not None and following.tag == qn("w:p") and re.match(r"^(?:表注|注)[：:]", "".join(following.itertext())):
            end = following
        end.addnext(section_break(True))
        count += 1
    assert count == 9
    return count


def clean_metadata(path):
    with ZipFile(path) as archive:
        entries = [(entry, archive.read(entry)) for entry in archive.infolist()]
    removed = []
    local = re.compile(r"(?<![\w])(?:[A-Za-z]:[\\/]|\\\\[^\\/\s<>]+\\|file:/+|/(?:Users|home)/)", re.I)
    rewritten = []
    for entry, data in entries:
        if entry.filename == "docProps/custom.xml":
            properties = etree.fromstring(data)
            for prop in list(properties):
                if prop.get("name", "").lower() in ("bibliography", "csl") or local.search("".join(prop.itertext())):
                    removed.append(prop.get("name"))
                    properties.remove(prop)
            data = etree.tostring(properties, encoding="UTF-8", xml_declaration=True)
        if entry.filename.endswith((".xml", ".rels")):
            assert not local.search(data.decode("utf-8")), f"Local path leak in {entry.filename}"
        rewritten.append((entry, data))
    temporary = path.with_name(".paper-metadata.docx")
    with ZipFile(temporary, "w") as archive:
        for entry, data in rewritten:
            archive.writestr(entry, data)
    temporary.replace(path)
    return removed


def order_properties(doc):
    sequences = {
        "pPr": "pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId cnfStyle rPr sectPr pPrChange",
        "rPr": "rStyle rFonts b bCs i iCs caps smallCaps strike dstrike outline shadow emboss imprint noProof snapToGrid vanish webHidden color spacing w kern position sz szCs highlight u effect bdr shd fitText vertAlign rtl cs em lang eastAsianLayout specVanish oMath rPrChange",
        "sectPr": "headerReference footerReference footnotePr endnotePr type pgSz pgMar paperSrc pgBorders lnNumType pgNumType cols formProt vAlign noEndnote titlePg textDirection bidi rtlGutter docGrid printerSettings sectPrChange",
        "tblPr": "tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize tblStyleColBandSize tblW jc tblCellSpacing tblInd tblBorders shd tblLayout tblCellMar tblLook tblCaption tblDescription tblPrChange",
        "tcPr": "cnfStyle tcW gridSpan hMerge vMerge tcBorders shd noWrap tcMar textDirection tcFitText vAlign hideMark cellIns cellDel cellMerge tcPrChange",
    }
    for tag, sequence in sequences.items():
        ranks = {qn("w:" + name): index for index, name in enumerate(sequence.split())}
        for root in (doc.styles.element, doc._element):
            for properties in root.xpath(".//w:" + tag):
                for child in sorted(properties, key=lambda node: ranks.get(node.tag, 999)):
                    properties.append(child)


def normalize_docx(path):
    doc = Document(path)
    configure_styles(doc)
    for section in doc.sections:
        section.page_width = Mm(210)
        section.page_height = Mm(297)
        section.top_margin = section.bottom_margin = Mm(22)
        section.left_margin = section.right_margin = Mm(23.5)
    references = False
    ref_count = 0
    for paragraph in doc.paragraphs:
        name = paragraph.style.name
        fmt = paragraph.paragraph_format
        text = paragraph.text.strip()
        fmt.first_line_indent = Pt(0)
        if name.startswith("Heading") and text == "参考文献":
            references = True
        elif references and text:
            paragraph.style = doc.styles["Research Reference"]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
            fmt.left_indent = Pt(20)
            fmt.first_line_indent = Pt(-20)
            fmt.keep_together = True
            fmt.keep_with_next = False
            fmt.space_after = Pt(7)
            fmt.line_spacing = 1.15
            for run in paragraph_runs(paragraph):
                set_font(run, 9)
            ref_count += 1
            continue
        if name.startswith("Heading"):
            size = {"Heading 1": 14, "Heading 2": 12, "Heading 3": 11.5}[name]
            fmt.keep_with_next = fmt.keep_together = True
            for run in paragraph_runs(paragraph):
                set_font(run, size, "黑体")
                run.bold = True
        elif name in ("Title", "Subtitle"):
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for border in paragraph._p.xpath("./w:pPr/w:pBdr"):
                border.getparent().remove(border)
            for run in paragraph_runs(paragraph):
                set_font(run, 20 if name == "Title" else 11, "黑体" if name == "Title" else "宋体")
                run.italic = False
        elif "Caption" in name or re.match(r"^表\s*\d", text):
            table_caption = bool(re.match(r"^表\s*\d", text))
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER if table_caption else WD_ALIGN_PARAGRAPH.LEFT
            fmt.keep_with_next = table_caption
            fmt.keep_together = True
            fmt.space_before, fmt.space_after = Pt(3), Pt(7)
            for run in paragraph_runs(paragraph):
                set_font(run, 9.5)
                run.bold = True
        elif re.match(r"^(?:表注|注)[：:]", text):
            fmt.space_before, fmt.space_after = Pt(3), Pt(6)
            fmt.line_spacing = 1.15
            fmt.keep_with_next = False
            for run in paragraph_runs(paragraph):
                set_font(run, 8.5)
        else:
            fmt.first_line_indent = Pt(22)
            fmt.line_spacing = 1.28
            fmt.space_after = Pt(5)
            fmt.keep_with_next = False
            paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            for run in paragraph_runs(paragraph):
                set_font(run, 11)
        if paragraph._p.xpath(".//w:drawing"):
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            fmt.first_line_indent = Pt(0)
            fmt.keep_with_next = True
            fmt.space_before = Pt(6)
        if paragraph._p.xpath(".//m:oMathPara"):
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            fmt.first_line_indent = Pt(0)
            fmt.keep_together = True
    assert ref_count == 74
    for shape in doc.inline_shapes:
        width = min(shape.width, Mm(161))
        shape.height = round(shape.height * width / shape.width)
        shape.width = width
    repaired = format_tables(doc)
    landscape_count = landscape_tables(doc)
    for root in (doc.styles.element, doc._element):
        for language in root.xpath(".//w:lang"):
            language.set(qn("w:val"), "en-US")
            language.set(qn("w:eastAsia"), "zh-CN")
        for color in root.xpath(".//w:color"):
            color.attrib.clear()
            color.set(qn("w:val"), "000000")
    doc.core_properties.author = ""
    doc.core_properties.last_modified_by = ""
    doc.core_properties.comments = ""
    element(doc.settings.element, "updateFields", val="true")
    order_properties(doc)
    doc.save(path)
    removed = clean_metadata(path)
    with ZipFile(path) as archive:
        assert archive.testzip() is None
        xml = etree.fromstring(archive.read("word/document.xml"))
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        assert not xml.xpath("//w:tblGrid[not(w:gridCol)]", namespaces=ns)
        assert len(xml.xpath("//w:tblHeader", namespaces=ns)) == 10
        assert len([n for n in archive.namelist() if n.startswith("word/media/")]) == 5
    return {"references": ref_count, "tables": len(doc.tables), "images": len(doc.inline_shapes),
            "table_columns": EXPECTED_COLUMNS, "repaired_empty_table_grids": repaired,
            "landscape_tables": landscape_count, "sections": len(doc.sections),
            "removed_custom_properties": removed, "local_absolute_path_leaks": 0,
            "visual_qa": "OOXML structural checks only; the independent TeX PDF has PyMuPDF previews"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-doc", type=Path, default=ROOT / "templates/v3_reference.docx")
    parser.add_argument("--output", type=Path, default=ROOT / "paper.docx")
    parser.add_argument("--report", type=Path, default=LOGS / "word-build-receipt.json")
    args = parser.parse_args()
    reference, output = args.reference_doc.resolve(), args.output.resolve()
    assert reference.is_relative_to(ROOT) and output.is_relative_to(ROOT)
    assert args.report.resolve().is_relative_to(ROOT)
    source_hash, template_hash = sha256(ROOT / "paper.md"), sha256(reference)
    ast = publication_ast()
    pandoc("--from=json", "--to=docx", "--standalone", "--citeproc", "--bibliography=references.bib",
           "--csl=numeric.csl", "--metadata=lang:zh-CN", "--metadata=link-citations:true",
           "--reference-doc=" + str(reference), "--resource-path=.", "--output=" + str(output),
           text=json.dumps(ast, ensure_ascii=False))
    report = normalize_docx(output)
    assert sha256(ROOT / "paper.md") == source_hash and sha256(reference) == template_hash
    report.update(bytes=output.stat().st_size, sha256=sha256(output),
                  source_sha256=source_hash, reference_template_sha256=template_hash)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
