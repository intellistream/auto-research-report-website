"""Build self-contained HTML and editable LaTeX from the same cited Markdown.

Requirements: Pandoc, beautifulsoup4. Run from this directory.
DOCX/PDF use build_word.py; this script never exports a second primary PDF.
"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
from bs4 import BeautifulSoup, Comment

ROOT = Path(__file__).resolve().parent

def run(*args):
    subprocess.run([str(a) for a in args], cwd=ROOT, check=True)

def main():
    pandoc = shutil.which('pandoc')
    if not pandoc: raise SystemExit('Pandoc is required on PATH')
    common = ['paper.md', '--standalone', '--citeproc', '--bibliography=references.bib',
              '--csl=numeric.csl', '--metadata=link-citations:true']
    help_text = subprocess.run([pandoc,'--help'], check=True, capture_output=True, text=True).stdout
    embed = '--embed-resources' if '--embed-resources' in help_text else '--self-contained'
    run(pandoc, *common, '--to=html5', '--mathml', embed,
        '--css=paper.css', '--output=paper.html')
    raw = (ROOT/'paper.html').read_text(encoding='utf-8')
    soup = BeautifulSoup(raw, 'html.parser')
    for comment in soup.find_all(string=lambda s: isinstance(s, Comment)):
        if '[if lt IE 9]' in comment and 'html5shiv' in comment:
            comment.extract()
    title = soup.select_one('header .title')
    if title: title['id'] = 'paper-title'
    references = soup.find(id='references')
    if references: references.name = 'h2'
    # Preserve the public chapter and subsection anchors while adding leaf IDs.
    for heading in soup.select('h1[id^="section-"],h2[id^="section-"],h3[id^="section-"]'):
        heading.name = 'h' + str(int(heading.name[1]) + 1)
    for t in soup.select('table'):
        wrapper = soup.new_tag('div', attrs={'class':'table-wrap'})
        t.wrap(wrapper)
    ref_map = {}
    for i,entry in enumerate(soup.select('.csl-entry[id^="ref-"]'), 1):
        key = entry['id'][4:]
        ref_map[key] = i
        entry['id'] = f'ref-{i}'
    source_text = (ROOT/'paper.md').read_text(encoding='utf-8')
    expected_keys = set(re.findall(r'@([A-Za-z][\w:-]*)',source_text))
    assert set(ref_map) == expected_keys, 'bibliography and used citation keys differ'
    for a in soup.select('a[href^="#ref-"]'):
        key = a['href'][5:]
        assert key in ref_map, key
        a['href'] = f'#ref-{ref_map[key]}'
        a['class'] = list(set(a.get('class',[])) | {'citation'})
    for span in soup.select('[data-cites]'):
        source_keys = span['data-cites'].split()
        assert all(k in ref_map for k in source_keys), source_keys
        span['data-source-keys'] = ' '.join(source_keys)
        span['data-cites'] = ' '.join(str(ref_map[k]) for k in source_keys)
    # Explicit source links remain present even where the CSL uses a DOI.
    result = subprocess.run([pandoc, 'references.bib', '--from=biblatex', '--to=csljson'],
                            cwd=ROOT, check=True, capture_output=True)
    identities = json.loads(result.stdout)
    for record in identities:
        entry = soup.find(id=f"ref-{ref_map[record['id']]}")
        url = record.get('URL') or ('https://doi.org/' + record['DOI'] if record.get('DOI') else None)
        if url and not entry.select('a[href^="http"]'):
            a = soup.new_tag('a', href=url)
            a.string = '原始来源'
            entry.append(' ')
            entry.append(a)
    ids = [e['id'] for e in soup.select('[id]')]
    assert len(ids) == len(set(ids)), 'duplicate anchors'
    assert not re.search(r'<\s*script\b', str(soup), re.I), 'standalone article must not execute scripts'
    for a in soup.select('a[href^="#"]'):
        assert a['href'][1:] in ids, a['href']
    expected_leaves = set(re.findall(r'(?m)^### .*?\{#(section-[^}]+)\}',source_text))
    assert {h['id'] for h in soup.select('h4[id^="section-"]')} == expected_leaves
    assert all(img['src'].startswith('data:image/') for img in soup.select('img'))
    (ROOT/'paper.html').write_text(str(soup), encoding='utf-8')
    (ROOT/'publication-reference-map.json').write_text(json.dumps(ref_map,ensure_ascii=False,indent=2), encoding='utf-8')
    (ROOT/'reference-identities.json').write_text(json.dumps(identities,ensure_ascii=False,indent=2), encoding='utf-8')
    # ctex owns Chinese language setup. Older Pandoc versions emit an empty
    # polyglossia language for zh-CN, so omit only that metadata for LaTeX.
    tex_source = re.sub(r'(?m)^lang: zh-CN\n', '', (ROOT/'paper.md').read_text(encoding='utf-8'))
    tex_args = [pandoc, *common[1:], '--from=markdown', '--to=latex', '--top-level-division=section',
        '--variable=documentclass:ctexart', '--variable=classoption:UTF8',
        '--variable=geometry:a4paper,margin=2.3cm', '--variable=fontsize:11pt',
        '--include-in-header=paper-header.tex', '--output=paper.tex']
    subprocess.run(tex_args, cwd=ROOT, input=tex_source.encode('utf-8'), check=True)
    report = {'citation_targets':len(ref_map),'analytical_leaf_headings':len(expected_leaves),
              'chapter_anchors':len(soup.select('h2[id^="section-"]')),'figures':len(soup.select('img')),
              'tables':len(soup.select('table')),'broken_fragment_links':0,
              'html_sha256':hashlib.sha256((ROOT/'paper.html').read_bytes()).hexdigest()}
    (ROOT/'web-build-receipt.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report))

if __name__ == '__main__': main()
