# 面向大语言模型推理的执行图优化研究综述 — editable source snapshot

Literature cutoff: 2026-11-23
Manuscript revision: v3-grounded-20261123

This package contains the editable Word manuscript, Markdown, independently
editable TeX, bibliography, PNG figures and formatting resources. It does not
contain downloaded third-party papers, authentication receipts or workflow logs.
The supplied build scripts and source registers preserve the current export
steps, citation-number map and versioned source identities.

## Word and PDF

The published PDF was exported from paper.docx. Open that file in Microsoft Word
to edit it and export a new PDF. Native equations, figure captions, table headers
and bibliography are editable. Word/font versions may change pagination and bytes.

To rebuild with the supplied Word formatting repairs, install Pandoc and Python
with python-docx, then run:

    python build_word.py --reference-doc paper.docx --output rebuilt.docx --pdf rebuilt.pdf

Review and render the result before replacing the published files. Later manual
Word edits are not copied back into Markdown automatically. The --pdf option
requires Windows and Microsoft Word; omit it to create only the editable DOCX.
Run python build_word.py --help for tool and path overrides.

## TeX alternative

paper.tex contains its rendered bibliography and references the PNG figures.
With XeLaTeX, ctex and the fonts named in paper.tex installed, run:

    xelatex -interaction=nonstopmode -halt-on-error paper.tex
    xelatex -interaction=nonstopmode -halt-on-error paper.tex

This produces a separate layout; its pagination need not match the Word PDF.

## HTML from Markdown

With Pandoc and Python with beautifulsoup4 installed, run:

    python build_web.py

This builds HTML and TeX from the same cited Markdown, applies the exporter's
compatibility handling, removes legacy active-content comments, normalizes
bibliography anchors to ref-1, ref-2, etc., and writes the citation-number map.
The headings already contain their numbers. HTML uses embedded figures and native
MathML. The exporter derives and checks citation and heading targets from the
Markdown source. Rebind the website's representative-work links to the new map
before import. Reimport completed outputs for a new immutable version.
