"""Build a Chinese research DOCX with Pandoc and the retained Word styles.

Requirements: Python with python-docx, Pandoc, and a reference DOCX.  The
optional --pdf export uses a new, hidden Microsoft Word instance on Windows.
All paths are arguments, environment overrides, or relative to this script.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from zipfile import ZipFile

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Mm, Pt, RGBColor, Twips
from docx.text.run import Run
from lxml import etree

HERE = Path(__file__).resolve().parent

WORD_EXPORT_PS = r'''
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$OutputEncoding = [Text.UTF8Encoding]::new($false)
$inputFile = [IO.Path]::GetFullPath($env:ACLGRAPH_WORD_INPUT)
$outputFile = [IO.Path]::GetFullPath($env:ACLGRAPH_WORD_OUTPUT)
$receiptFile = $env:ACLGRAPH_WORD_RECEIPT
$beforeIds = @(Get-Process WINWORD -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class AclGraphWordWindow {
    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint processId);
}
'@
$word = $null; $document = $null; $ownedInstance = $false
try {
    $word = New-Object -ComObject Word.Application
    $newIds = @(Get-Process WINWORD -ErrorAction SilentlyContinue |
        Where-Object { $beforeIds -notcontains $_.Id } | ForEach-Object { $_.Id })
    if (($newIds.Count -ne 1) -or ($word.Documents.Count -ne 0)) {
        throw 'Word automation did not produce a verified independent instance.'
    }
    [uint32]$wordOwnerId = $newIds[0]
    $ownedInstance = $true
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $word.ScreenUpdating = $false
    $word.AutomationSecurity = 3
    # Read-only, no recent-files entry, no changes to the retained/source DOCX.
    $document = $word.Documents.Open($inputFile, $false, $true, $false)
    [uint32]$windowOwnerId = 0
    [void][AclGraphWordWindow]::GetWindowThreadProcessId(
        [IntPtr]([Int64]$document.ActiveWindow.Hwnd), [ref]$windowOwnerId)
    if ($windowOwnerId -ne $wordOwnerId) {
        $ownedInstance = $false
        throw 'The document window does not belong to the new Word process.'
    }
    [void]$document.Fields.Update()
    foreach ($section in $document.Sections) {
        foreach ($footer in $section.Footers) { [void]$footer.Range.Fields.Update() }
        foreach ($header in $section.Headers) { [void]$header.Range.Fields.Update() }
    }
    $document.Repaginate()
    $pageCount = $document.ComputeStatistics(2)
    # Print quality; preserve searchable text, structure tags, and headings.
    $document.ExportAsFixedFormat($outputFile, 17, $false, 0, 0, 1, 1, 0,
        $false, $false, 1, $true, $false, $false)
    $receipt = [ordered]@{
        backend = 'Microsoft Word COM ExportAsFixedFormat'
        application_version = [string]$word.Version
        independent_process_verified = $true
        word_process_id = [int]$wordOwnerId
        visible = $false
        source_opened_read_only = $true
        source_saved = $false
        page_count = [int]$pageCount
        table_count = [int]$document.Tables.Count
        inline_shape_count = [int]$document.InlineShapes.Count
        pdf_exists = [IO.File]::Exists($outputFile)
    }
    $result = $receipt | ConvertTo-Json -Depth 5
    if ($receiptFile) { [IO.File]::WriteAllText($receiptFile, $result, [Text.UTF8Encoding]::new($false)) }
    Write-Output $result
} finally {
    if ($document -ne $null) {
        $document.Close(0)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($document)
    }
    if (($word -ne $null) -and $ownedInstance) { $word.Quit() }
    if ($word -ne $null) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($word) }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}
'''


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sanitize_build_metadata(path: Path) -> dict:
    """Remove Pandoc's local build paths without rewriting displayed parts."""
    target = "docProps/custom.xml"
    with ZipFile(path) as source:
        entries = [(item, source.read(item.filename)) for item in source.infolist()]
        archive_comment = source.comment
    payloads = {item.filename: data for item, data in entries}
    if len(payloads) != len(entries):
        raise RuntimeError("Duplicate DOCX package parts prevent metadata-only verification.")
    removed = []
    if target in payloads:
        root = etree.fromstring(payloads[target])
        for prop in list(root):
            if prop.get("name") in {"bibliography", "csl"}:
                removed.append(prop.get("name")); root.remove(prop)
        if removed:
            replacement = etree.tostring(root, encoding="UTF-8", xml_declaration=True)
            handle, temp_name = tempfile.mkstemp(prefix="word_metadata_", suffix=".docx", dir=path.parent)
            os.close(handle)
            temporary = Path(temp_name)
            try:
                with ZipFile(temporary, "w") as destination:
                    destination.comment = archive_comment
                    for item, data in entries:
                        destination.writestr(item, replacement if item.filename == target else data)
                with ZipFile(temporary) as result:
                    if result.testzip() is not None:
                        raise RuntimeError("DOCX metadata rewrite failed its ZIP integrity check.")
                    after = {name: result.read(name) for name in result.namelist()}
                changed = [name for name in payloads if payloads[name] != after.get(name)]
                if set(payloads) != set(after) or changed != [target]:
                    raise RuntimeError("Metadata-only rewrite unexpectedly changed displayed DOCX parts.")
                temporary.replace(path)
                payloads = after
            finally:
                if temporary.exists(): temporary.unlink()
    # Inspect all XML and relationship parts, including hidden metadata.  The
    # boundary excludes the final letter of ordinary https:// namespace URLs.
    local_path = re.compile(r"(?<![\w])(?:[A-Za-z]:[\\/]|\\\\[^\\/\s<>]+\\|file:/+|/(?:Users|home)/)", re.I)
    leaks = [name for name, data in payloads.items()
             if name.endswith((".xml", ".rels")) and local_path.search(data.decode("utf-8"))]
    if leaks:
        raise RuntimeError("Local paths remain in DOCX package parts: " + ", ".join(leaks))
    return {"removed_build_properties": removed,
            "render_parts_byte_identical": True,
            "private_absolute_path_parts": leaks}


def native_word_pdf(docx_path: Path, pdf_path: Path, receipt: Path | None = None) -> dict:
    if os.name != "nt":
        raise RuntimeError("Native Word PDF export requires Windows and Microsoft Word.")
    shell = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
    if not shell:
        raise RuntimeError("PowerShell is required for native Word export.")
    docx_path = docx_path.resolve()
    pdf_path = pdf_path.resolve()
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    before = sha256(docx_path)
    env = os.environ.copy()
    env.update(ACLGRAPH_WORD_INPUT=str(docx_path), ACLGRAPH_WORD_OUTPUT=str(pdf_path),
               ACLGRAPH_WORD_RECEIPT=str(receipt.resolve()) if receipt else "")
    process = subprocess.run([shell, "-NoProfile", "-NonInteractive", "-Command", WORD_EXPORT_PS],
        env=env, capture_output=True, text=True, encoding="utf-8", errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=240)
    if process.returncode:
        raise RuntimeError("Independent Word PDF export failed:\n" + process.stdout + process.stderr)
    if not pdf_path.is_file() or not pdf_path.read_bytes().startswith(b"%PDF-"):
        raise RuntimeError("Word did not produce a real PDF.")
    if sha256(docx_path) != before:
        raise RuntimeError("Read-only Word export unexpectedly changed its source DOCX.")
    if receipt and receipt.is_file():
        data = json.loads(receipt.read_text(encoding="utf-8-sig"))
    else:
        data = {"backend": "Microsoft Word COM", "log": process.stdout.strip()}
    data.update(docx_sha256=before, pdf_sha256=sha256(pdf_path), source_docx_unchanged=True)
    if receipt:
        receipt.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return data


def font_properties(owner, size: float, east_asia: str = "宋体", western: str = "Times New Roman"):
    owner.font.name = western
    owner.font.size = Pt(size)
    owner.font.color.rgb = RGBColor(0, 0, 0)
    rpr = owner._element.get_or_add_rPr()
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts"); rpr.insert(0, fonts)
    for name, value in [("ascii", western), ("hAnsi", western), ("eastAsia", east_asia), ("cs", western)]:
        fonts.set(qn("w:" + name), value)
    for attr in list(fonts.attrib):
        if attr.lower().endswith("theme"):
            del fonts.attrib[attr]
    for name in ["sz", "szCs"]:
        el = rpr.find(qn("w:" + name))
        if el is None: el = OxmlElement("w:" + name); rpr.append(el)
        el.set(qn("w:val"), str(round(size * 2)))
    color = rpr.find(qn("w:color"))
    if color is not None:
        color.attrib.clear(); color.set(qn("w:val"), "000000")


def remove_p_borders(element):
    for child in list(element):
        if child.tag == qn("w:pBdr"):
            element.remove(child)


def no_midword_wrap(paragraph):
    pr = paragraph._p.get_or_add_pPr()
    setting = pr.find(qn("w:wordWrap"))
    if setting is None: setting = OxmlElement("w:wordWrap"); pr.append(setting)
    # This flag alone does not prevent mixed-script breaks.  Native Word
    # verifies this setting together with normalize_mixed_language below;
    # do not infer its COM behavior from the similarly named API property.
    setting.set(qn("w:val"), "1")


def normalize_mixed_language(doc):
    # Pandoc can set the primary Latin language to zh-CN while retaining an
    # en-US East Asian language from the reference document.  Native Word then
    # breaks Latin names and even decimal numbers as East Asian characters.
    # Preserve Chinese text/fonts; tag each script with its intended language.
    for root in [doc.styles.element, doc._element]:
        for language in root.xpath(".//w:lang"):
            language.set(qn("w:val"), "en-US")
            language.set(qn("w:eastAsia"), "zh-CN")
    # python-docx setters and manually inserted flags can otherwise leave
    # paragraph properties out of schema order.  Keep the Word XML portable.
    sequence = ("pStyle keepNext keepLines pageBreakBefore framePr widowControl "
        "numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku "
        "wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi "
        "adjustRightInd snapToGrid spacing ind contextualSpacing mirrorIndents "
        "suppressOverlap jc textDirection textAlignment textboxTightWrap "
        "outlineLvl divId cnfStyle rPr sectPr pPrChange").split()
    ranks = {qn("w:" + tag): i for i, tag in enumerate(sequence)}
    for root in [doc.styles.element, doc._element]:
        for properties in root.xpath(".//w:pPr"):
            for child in sorted(list(properties), key=lambda item: ranks.get(item.tag, 999)):
                properties.append(child)


def configure_styles(doc):
    body = ["Normal", "Body Text", "First Paragraph", "Abstract"]
    for name in body:
        if name not in doc.styles: continue
        style = doc.styles[name]; font_properties(style, 11)
        p = style.paragraph_format
        p.line_spacing = 307 / 240
        p.space_after = Pt(5)
        p.first_line_indent = Pt(22)
        p.widow_control = True
        p.keep_with_next = False
    for name, size in [("Title", 20), ("Subtitle", 11), ("Heading 1", 14), ("Heading 2", 12), ("Heading 3", 11.5)]:
        if name not in doc.styles: continue
        style = doc.styles[name]; font_properties(style, size, "黑体", "黑体")
        style.font.bold = name != "Subtitle"
        style.font.italic = False
        style.font.underline = False
        p = style.paragraph_format
        p.first_line_indent = Pt(0); p.keep_with_next = True; p.keep_together = True
        p.space_before = Pt(13 if name.startswith("Heading") else 0)
        p.space_after = Pt(7); p.line_spacing = 1.0 if name in ["Title", "Subtitle"] else 307 / 240
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER if name in ["Title", "Subtitle"] else WD_ALIGN_PARAGRAPH.LEFT
        remove_p_borders(style.element.get_or_add_pPr())
        num = style.element.get_or_add_pPr().find(qn("w:numPr"))
        if num is not None: style.element.get_or_add_pPr().remove(num)
        if name == "Subtitle":
            font_properties(style, 11)
            for tag in ["spacing", "i", "iCs"]:
                el = style.element.get_or_add_rPr().find(qn("w:" + tag))
                if el is not None: style.element.get_or_add_rPr().remove(el)
    for name in ["Caption", "Image Caption", "Table Caption"]:
        if name not in doc.styles: continue
        style = doc.styles[name]; font_properties(style, 9.5); style.font.bold = True
        style.paragraph_format.first_line_indent = Pt(0)
        style.paragraph_format.line_spacing = 278 / 240
    for name in ["Bibliography", "Research Reference"]:
        if name not in doc.styles: continue
        style = doc.styles[name]; font_properties(style, 9)
        p = style.paragraph_format
        p.line_spacing = 259 / 240; p.space_after = Pt(7)
        p.left_indent = Pt(20); p.first_line_indent = Pt(-20)
        p.keep_together = True; p.keep_with_next = False
    for name in ["Hyperlink", "FollowedHyperlink"]:
        if name in doc.styles:
            doc.styles[name].font.color.rgb = RGBColor(0, 0, 0)
            doc.styles[name].font.underline = False


def border(container, name, val, size=0):
    el = container.find(qn("w:" + name))
    if el is None: el = OxmlElement("w:" + name); container.append(el)
    el.attrib.clear(); el.set(qn("w:val"), val)
    if val != "nil":
        el.set(qn("w:sz"), str(size)); el.set(qn("w:color"), "000000")


def column_weights(table):
    n = len(table.columns)
    header = [c.text.replace(" ", "") for c in table.rows[0].cells]
    if n == 3: return [0.16, 0.26, 0.58]
    if n == 4:
        return [0.20, 0.29, 0.37, 0.14] if any("位置" in t or "页" in t for t in header[-1:]) else [0.19, 0.27, 0.27, 0.27]
    if n == 5:
        return [0.19, 0.22, 0.22, 0.24, 0.13] if "位置" in header[-1] or "页" in header[-1] else [0.18, 0.17, 0.23, 0.22, 0.20]
    return [1 / n] * n


def format_tables(doc, width_twips):
    for table in doc.tables:
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = False
        weights = column_weights(table)
        widths = [round(width_twips * x) for x in weights]
        widths[-1] += width_twips - sum(widths)
        for grid, value in zip(table._tbl.tblGrid.gridCol_lst, widths): grid.set(qn("w:w"), str(value))
        pr = table._tbl.tblPr
        tblw = pr.find(qn("w:tblW")); tblw.set(qn("w:type"), "dxa"); tblw.set(qn("w:w"), str(width_twips))
        borders = pr.find(qn("w:tblBorders"))
        if borders is None: borders = OxmlElement("w:tblBorders"); pr.append(borders)
        for edge in ["top", "bottom", "left", "right", "insideH", "insideV"]:
            border(borders, edge, "single" if edge in ["top", "bottom"] else "nil", 12)
        for row_index, row in enumerate(table.rows):
            trpr = row._tr.get_or_add_trPr()
            for el in list(trpr):
                if el.tag == qn("w:trHeight"): trpr.remove(el)
            if trpr.find(qn("w:cantSplit")) is None: trpr.append(OxmlElement("w:cantSplit"))
            if row_index == 0 and trpr.find(qn("w:tblHeader")) is None: trpr.append(OxmlElement("w:tblHeader"))
            cursor = 0
            for tc in row._tr.tc_lst:
                tcpr = tc.get_or_add_tcPr()
                span = tcpr.find(qn("w:gridSpan")); count = int(span.get(qn("w:val"))) if span is not None else 1
                w = tcpr.find(qn("w:tcW"))
                if w is None: w = OxmlElement("w:tcW"); tcpr.append(w)
                w.set(qn("w:type"), "dxa"); w.set(qn("w:w"), str(sum(widths[cursor:cursor + count]))); cursor += count
                mar = tcpr.find(qn("w:tcMar"))
                if mar is None: mar = OxmlElement("w:tcMar"); tcpr.append(mar)
                for edge, value in [("top", 75), ("bottom", 75), ("left", 85), ("right", 85)]:
                    e = mar.find(qn("w:" + edge))
                    if e is None: e = OxmlElement("w:" + edge); mar.append(e)
                    e.set(qn("w:w"), str(value)); e.set(qn("w:type"), "dxa")
                shd = tcpr.find(qn("w:shd"))
                if shd is not None: tcpr.remove(shd)
                if row_index == 0:
                    cb = tcpr.find(qn("w:tcBorders"))
                    if cb is None: cb = OxmlElement("w:tcBorders"); tcpr.append(cb)
                    border(cb, "bottom", "single", 6)
            for cell in row.cells:
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                for p in cell.paragraphs:
                    no_midword_wrap(p)
                    p.paragraph_format.first_line_indent = Pt(0)
                    p.paragraph_format.left_indent = Pt(0); p.paragraph_format.right_indent = Pt(0)
                    p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0)
                    p.paragraph_format.line_spacing = 1.1
                    p.paragraph_format.keep_with_next = row_index == 0
                    p.paragraph_format.keep_together = False
                    p.paragraph_format.widow_control = False
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if row_index == 0 else WD_ALIGN_PARAGRAPH.LEFT
                    for run in p.runs:
                        font_properties(run, 9.5)
                        if row_index == 0: run.bold = True


def normalize_docx(path: Path):
    doc = Document(path)
    configure_styles(doc)
    for s in doc.sections:
        s.page_width = Mm(210); s.page_height = Mm(297)
        s.top_margin = Mm(21.996); s.bottom_margin = Mm(21.996)
        s.left_margin = Mm(23.495); s.right_margin = Mm(23.495)
        s.header_distance = Mm(12.7); s.footer_distance = Mm(11.007)
    in_references = False
    reference_count = 0
    for p in doc.paragraphs:
        name = p.style.name
        no_midword_wrap(p)
        if name.startswith("Heading") and p.text.strip() in ["参考文献", "References"]:
            in_references = True
        elif in_references and p.text.strip():
            # Pandoc 2.12 emits numeric CSL bibliography entries as Normal.
            p.style = doc.styles["Research Reference"]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            fmt = p.paragraph_format
            fmt.line_spacing = 259 / 240; fmt.space_before = Pt(0); fmt.space_after = Pt(7)
            fmt.left_indent = Pt(20); fmt.right_indent = Pt(0); fmt.first_line_indent = Pt(-20)
            fmt.keep_together = True; fmt.keep_with_next = False
            for element in p._p.xpath(".//w:r"):
                font_properties(Run(element, p), 9)
            reference_count += 1
            continue
        if name.startswith("Heading"):
            size = {"Heading 1": 14, "Heading 2": 12, "Heading 3": 11.5}.get(name, 11.5)
            p.paragraph_format.keep_with_next = True; p.paragraph_format.keep_together = True
            p.paragraph_format.first_line_indent = Pt(0)
            for run in p.runs: font_properties(run, size, "黑体", "黑体"); run.bold = True
        elif name in ["Title", "Subtitle"]:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.first_line_indent = Pt(0)
            remove_p_borders(p._p.get_or_add_pPr())
            for run in p.runs:
                font_properties(run, 20, "黑体", "黑体") if name == "Title" else font_properties(run, 11)
                if name == "Subtitle": run.italic = False
        elif "Caption" in name:
            p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.space_before = Pt(3); p.paragraph_format.space_after = Pt(7)
            p.paragraph_format.keep_together = True
            is_table = name == "Table Caption" or bool(re.match(r"^表\s*\d", p.text))
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if is_table else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.keep_with_next = is_table
            for run in p.runs: font_properties(run, 9.5); run.bold = True
        elif name in ["Bibliography", "Research Reference"]:
            if "Research Reference" in doc.styles: p.style = doc.styles["Research Reference"]
            for run in p.runs: font_properties(run, 9)
        else:
            p.paragraph_format.first_line_indent = Pt(22)
            p.paragraph_format.line_spacing = 307 / 240
            p.paragraph_format.space_after = Pt(5)
            p.paragraph_format.keep_with_next = False
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            for run in p.runs: font_properties(run, 11)
        if p._p.xpath(".//w:drawing"):
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.keep_with_next = True
            p.paragraph_format.space_before = Pt(6)
        if p._p.xpath(".//m:oMathPara"):
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.keep_together = True
    for shape in doc.inline_shapes:
        width = min(shape.width, Mm(161))
        ratio = width / shape.width
        shape.width = width; shape.height = round(shape.height * ratio)
    format_tables(doc, round((doc.sections[0].page_width - doc.sections[0].left_margin - doc.sections[0].right_margin) / 635))
    # Override theme-derived link colors too, without changing displayed content.
    for color in doc._element.xpath(".//w:color"):
        color.attrib.clear(); color.set(qn("w:val"), "000000")
    for p in doc.sections[0].footer.paragraphs:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    props = doc.core_properties
    props.author = ""; props.last_modified_by = ""; props.comments = ""
    settings = doc.settings.element
    update = settings.find(qn("w:updateFields"))
    if update is None: update = OxmlElement("w:updateFields"); settings.append(update)
    update.set(qn("w:val"), "true")
    normalize_mixed_language(doc)
    doc.save(path)
    privacy = sanitize_build_metadata(path)
    return {"paragraphs": len(doc.paragraphs), "tables": len(doc.tables), "images": len(doc.inline_shapes),
            "reference_count": reference_count,
            "metadata_privacy": privacy,
            "sections": len(doc.sections), "body_font_pt": 11, "table_font_pt": 9.5,
            "heading_font_pt": [14, 12, 11.5], "page_system": "A4 portrait, retained Chinese paper margins"}


def run_pandoc(binary, args, *, cwd, text=None):
    proc = subprocess.run([binary, *args], cwd=cwd, input=text, capture_output=True,
                          text=True, encoding="utf-8", errors="strict")
    if proc.returncode: raise RuntimeError(proc.stderr)
    return proc.stdout


def convert_raw_html(ast, pandoc, cwd):
    def visit(value):
        if isinstance(value, list):
            out = []
            for item in value:
                if isinstance(item, dict) and item.get("t") == "RawBlock" and item["c"][0] == "html" and "<table" in item["c"][1]:
                    converted = json.loads(run_pandoc(pandoc, ["--from=html", "--to=json"], cwd=cwd, text=item["c"][1]))
                    out.extend(converted["blocks"])
                else: out.append(visit(item))
            return out
        if isinstance(value, dict): return {k: visit(v) for k, v in value.items()}
        return value
    return visit(ast)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", type=Path, default=HERE / "paper.md")
    p.add_argument("--bibliography", type=Path, default=HERE / "references.bib")
    p.add_argument("--csl", type=Path, default=HERE / "numeric.csl")
    p.add_argument("--output", type=Path, default=HERE / "paper.docx")
    p.add_argument("--reference-doc", type=Path)
    p.add_argument("--pandoc", default=os.environ.get("PANDOC_BINARY") or shutil.which("pandoc"))
    p.add_argument("--pdf", type=Path, help="Optional native Word PDF output on Windows")
    p.add_argument("--report", type=Path, help="Optional private build receipt")
    a = p.parse_args()
    if not a.pandoc: raise RuntimeError("Pandoc not found; pass --pandoc or PANDOC_BINARY.")
    source = a.source.resolve(); output = a.output.resolve()
    reference = (a.reference_doc or output).resolve()
    for path in [source, a.bibliography, a.csl, reference]:
        if not path.is_file(): raise FileNotFoundError(str(path) + "; pass --reference-doc for the first build")
    source_hash = sha256(source); reference_hash = sha256(reference)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="research_word_") as temp:
        template = Path(temp) / "reference.docx"
        shutil.copyfile(reference, template)
        ast = json.loads(run_pandoc(a.pandoc, [str(source), "--from=markdown", "--to=json"], cwd=source.parent))
        ast = convert_raw_html(ast, a.pandoc, source.parent)
        # Preserve the source's numbered chapter/subsection/leaf hierarchy.
        json_input = json.dumps(ast, ensure_ascii=False)
        run_pandoc(a.pandoc, ["--from=json", "--to=docx", "--standalone", "--citeproc",
            "--bibliography=" + str(a.bibliography.resolve()), "--csl=" + str(a.csl.resolve()),
            "--metadata=lang:zh-CN", "--reference-doc=" + str(template),
            "--resource-path=" + str(source.parent), "--output=" + str(output)], cwd=source.parent, text=json_input)
    facts = normalize_docx(output)
    if sha256(source) != source_hash: raise RuntimeError("Source Markdown changed during build.")
    report = {"source_sha256": source_hash, "reference_sha256": reference_hash,
              "docx_sha256": sha256(output), "pandoc_version": run_pandoc(a.pandoc, ["--version"], cwd=source.parent).splitlines()[0], **facts}
    if a.pdf: report["pdf"] = native_word_pdf(output, a.pdf)
    if a.report:
        a.report.parent.mkdir(parents=True, exist_ok=True)
        a.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
