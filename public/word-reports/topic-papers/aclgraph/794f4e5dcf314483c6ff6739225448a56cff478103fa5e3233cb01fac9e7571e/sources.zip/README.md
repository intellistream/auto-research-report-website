# 执行图优化综述 v2

本包对应 2026-11-23 已确认的 Word 稿件，包含全文、原图和可编辑格式。

- paper.docx：本版排版原件，9 张三线表、黑体标题和可点击的文献标注。
- paper.pdf：由同一 Word 原件导出的 32 页 PDF。
- paper.html：自包含网页，含原生 MathML 和文献锚点，无远程资源或脚本。
- paper-editable.html、paper.css、figures/：网页的可编辑版本及原图。
- paper.md、paper.tex、references.bib：由同版内容转换的编辑格式。LaTeX 已通过 XeLaTeX 编译检查；它和 Word 的分页可因字体与排版引擎而不同。

保留同版 PDF 排版时，请编辑 Word 并由 Word 导出 PDF。LaTeX 使用 XeLaTeX、ctex 和 Windows 宋体/黑体，可运行：

    xelatex -interaction=nonstopmode -halt-on-error paper.tex
    xelatex -interaction=nonstopmode -halt-on-error paper.tex

网页内容和样式可直接编辑 paper-editable.html。使用 Pandoc 可重新嵌入本地图片，生成自包含网页：

    pandoc paper-editable.html --from=html --to=html5 --standalone --mathml --self-contained --css=paper.css --output=paper.html

引用编号沿用 Word 稿件，ref-1 至 ref-47 指向文末条目。修改多个编辑格式后请同步核对正文和引用。
